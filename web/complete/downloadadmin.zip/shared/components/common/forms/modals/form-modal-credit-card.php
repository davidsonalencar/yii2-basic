<!-- Form Modal 1 -->
<a href="#modal-credit-card" data-toggle="modal" class="btn btn-success"> <i class="fa fa-fw fa-credit-card"></i> Modal Credit Card</a>
	
<!-- Modal -->
<div class="modal fade" id="modal-credit-card">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal heading -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title">Payment</h3>
			</div>
			<!-- // Modal heading END -->
			
			<!-- Modal body -->
			<div class="modal-body">
				
				<div class="innerAll">
					<form class="margin-none innerLR inner-2x">
					  	<div class="form-group">
					    	<label for="exampleInputEmail1">Cardholder Name</label>
					    	<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Name on Card">
					  	</div>
					  	<div class="form-group">
					    	<label for="exampleInputEmail1">Card Number</label>
					    	<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter Card Number">
					  	</div>
					  	<div class="form-group">
							<label for="exampleInputPassword1">Expiry Date</label>
							<div class="row">
								<div class="col-md-3">
									<select class="form-control selectpicker">
						  				<option>1</option>
						  				<option>2</option>
						  				<option>3</option>
						  				<option>4</option>
						  				<option>5</option>
						  				<option>6</option>
						  				<option>7</option>
						  				<option>8</option>
						  				<option>9</option>
					  					<option>10</option>
						  				<option>11</option>
									</select>	
								</div>
								<div class="col-md-3">
									<select class="form-control selectpicker">
										<option>2013</option>
									  	<option>2014</option>
									  	<option>2015</option>
									  	<option>2016</option>
									  	<option>2017</option>
									  	<option>2018</option>
									</select>
								</div>
							</div>
						</div>
					  	<div class="form-group">
				    		<label for="exampleInputPassword1">Security Code <i class="fa fa-question-circle"></i></label>
				  			<div class="row">
				  				<div class="col-md-6">
				  					<input type="password" class="form-control" placeholder="CVV / CVV2">
				  				</div>
				  			</div>
					  	</div>
					  	<div class="text-center innerAll">
							<a href="" class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Make Payment</a>
						</div>
					</form>
				</div>

			</div>
			<!-- // Modal body END -->
	
		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}