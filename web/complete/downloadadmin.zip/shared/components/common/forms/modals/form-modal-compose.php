<!-- Form Modal 1 -->
<a href="#modal-compose" data-toggle="modal" class="btn btn-success"><i class="fa fa-fw fa-envelope"></i> Compose Email Modal</a>
	
{{php.form-modal-compose.modal}}