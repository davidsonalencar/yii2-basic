<!-- Form Modal 1 -->
<a href="#modal-login" data-toggle="modal" class="btn btn-primary"><i class="fa fa-fw fa-user"></i> Modal Login Form</a>
	
<!-- Modal -->
<div class="modal fade" id="modal-login">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal heading -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title">Login</h3>
			</div>
			<!-- // Modal heading END -->
			
			<!-- Modal body -->
			<div class="modal-body">
				<div class="innerAll">
					<div class="innerLR">
						{{php.input-horizontal}}
					</div>
				</div>
			</div>
			<!-- // Modal body END -->
	
		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}