<a href="#" class="thumbnail"><img data-src="holder.js/100%x180" alt="100%x180 Holder Image" /></a>

{{js.holder}}