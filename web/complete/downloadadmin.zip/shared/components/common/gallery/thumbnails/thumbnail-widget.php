<!-- Thumbnail -->
<div class="thumbnail widget-thumbnail">
	<img data-src="holder.js/100%x200" alt="100%x200 Image Holder" />
	<div class="caption">
		<h4>Thumbnail heading</h4>
		<p>Cras justo odio, dapibus ac facidivsis in, egestas eget quam. Donec id edivt non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id edivt.</p>
		<a href="#" class="btn btn-primary">Action</a>
		<a href="#" class="btn btn-inverse">Action</a>
	</div>
</div>
<!-- // Thumbnail END -->

{{js.holder}}
{{less.buttons}}