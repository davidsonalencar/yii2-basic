<!-- Slider -->
<div class="sliders-vertical">
    <span>77</span>
    <span>55</span>
    <span>33</span>
    <span>40</span>
    <span>45</span>
    <div class="clearfix"></div>
</div>
<!-- // Slider END -->

{{component.jqueryui-slider}}
{{builder.saveComponent.original}}