<!-- Slider -->
<div class="slider-single slider-primary"></div>

{{component.jqueryui-slider}}
{{builder.saveComponent.original}}