<!-- Slider -->
<div class="range-slider row">
	<div class="col-md-3"><input type="text" class="amount form-control" /></div>
	<div class="col-md-9" style="padding-top: 9px;"><div class="slider slider-primary"></div></div>
</div>
<!-- // Slider END -->

{{component.jqueryui-slider}}
{{builder.saveComponent.original}}