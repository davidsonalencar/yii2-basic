<!-- Slider -->
<div class="slider-range-max row form-horizontal">
	<div class="col-md-3">
		<div class="control-group">
		    <label class="col-md-8 control-label">Maximum price:</label>
		    <div class="col-md-4 padding-none">
		    	<input type="text" class="amount form-control" />
		    </div>
		</div>
	</div>
	<div class="col-md-9" style="padding-top: 9px;">
		<div class="slider slider-primary"></div>
	</div>
</div>
<!-- // Slider END -->

{{component.jqueryui-slider}}
{{builder.saveComponent.original}}