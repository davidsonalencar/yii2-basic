<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderWArrows" class="rangeslider-warning"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}