<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSlider"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}