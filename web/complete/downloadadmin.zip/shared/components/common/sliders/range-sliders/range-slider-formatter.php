<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderFormatter"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}