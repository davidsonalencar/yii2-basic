<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderRuler" class="rangeslider-danger"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}