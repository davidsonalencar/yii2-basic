<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderRulerDate" class="rangeslider-success"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}