<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderWheelZoom"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}