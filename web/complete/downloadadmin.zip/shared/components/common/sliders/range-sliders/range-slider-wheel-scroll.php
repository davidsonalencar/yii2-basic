<!-- Slider -->
<div class="sliderContainer">
	<div id="rangeSliderWheelScroll"></div>
</div>
<!-- // Slider END -->

{{component.range-sliders}}
{{builder.saveComponent.original}}