<div class="well">
	<address class="margin-none">
		<h2>John Doe</h2>
		<strong>Business manager</strong> at 
		<strong><a href="#">Business</a></strong><br> 
		<abbr title="Work email">e-mail:</abbr> <a href="mailto:#">john.doe@mybiz.com</a><br /> 
		<abbr title="Work Phone">phone:</abbr> (012) 345-678-901<br/>
		<abbr title="Work Fax">fax:</abbr> (012) 678-132-901
		<div class="separator bottom"></div>
		<p class="margin-none"><strong>You can also find us:</strong><br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tristique rutrum libero, vel bibendum nunc consectetur sed.</p>
	</address>
</div>
{{component.wells}}