<!-- Widget -->
<div class="widget widget-heading-simple widget-body-gray">
		
	<!-- Widget Heading -->
	<div class="widget-head">
		<h4 class="heading glyphicons list"><i></i>Categories</h4>
	</div>
	<!-- // Widget Heading END -->
	
	<div class="widget-body list">
	
		<!-- List -->
		<ul>
			<li>
				<a href="">Make Up</a>
				<span class="badge">35</span>
			</li>
			<li>
				<a href="">Fragrances</a>
				<span class="badge">30</span>
			</li>
			<li>
				<a href="">Nails</a>
				<span class="badge">19</span>
			</li>
			<li>
				<a href="">Hair Products</a>
				<span class="badge">33</span>
			</li>
			<li>
				<a href="">Accessories</a>
				<span class="badge">17</span>
			</li>
		</ul>
		<!-- // List END -->
		
	</div>
</div>
<!-- // Widget END -->