<!-- List Widget -->
<div class="widget">
	<div class="widget-head">
		<h4 class="heading glyphicons history"><i></i>List Widget</h4>
		<a href="" class="details pull-right">link</a>
	</div>
	<div class="widget-body list">
		<ul>
			<li>
				<span>List item #1</span>
				<span class="count">&euro;5,900</span>
			</li>
			<li>
				<span>List item #2</span>
				<span class="count">36,900</span>
			</li>
			<li>
				<span>List item #3</span>
				<span class="count">55,200</span>
			</li>
			<li>
				<span>List item #4</span>
				<span class="count">26,300</span>
			</li>
		</ul>
	</div>
</div>
<!-- // List Widget END -->