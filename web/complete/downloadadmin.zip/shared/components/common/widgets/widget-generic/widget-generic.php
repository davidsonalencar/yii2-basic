<div class="box-generic">
	<h3>Generic Widget</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto, nam non rerum tenetur ullam ratione dignissimos facere quod laudantium est itaque adipisci nostrum necessitatibus eveniet quibusdam ipsum explicabo alias. Quis, perferendis, accusantium, voluptatibus, ipsam architecto error esse tempore debitis quam facere itaque obcaecati odit laudantium maxime quibusdam earum fugiat. Dolorem, laudantium, autem amet libero illum dignissimos reiciendis temporibus aliquam totam.</p>
</div>
{{component.widget-generic}}