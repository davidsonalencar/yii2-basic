<!-- Accordion #2 Style -->
<div class="panel-group accordion accordion-2" id="tabAccountAccordion">

	<!-- Accordion Item -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-1-1"><i></i>Lorem ipsum dolor sit amet?</a></h4>
	    </div>
	    <div id="collapse-1-1" class="panel-collapse collapse in">
	      	<div class="panel-body">
	        	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tristique rutrum libero, vel bibendum nunc consectetur sed.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
  	<!-- Accordion Item -->
  	<div class="panel panel-default">
	    <div class="panel-heading">
	      	<h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-2-1"><i></i>Quisque porttitor elit ac mauris?</a></h4>
	    </div>
	    <div id="collapse-2-1" class="panel-collapse collapse">
	    	<div class="panel-body">
	        	Quisque porttitor elit ac mauris aliquam sollicitudin. Nam imperdiet ligula et dolor pulvinar consequat. Sed in turpis id erat vehicula gravida.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
  	<!-- Accordion Item -->
  	<div class="panel panel-default">
	    <div class="panel-heading">
	      	<h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-3-1"><i></i>Vivamus eros tortor consequat sed?</a></h4>
	    </div>
	    <div id="collapse-3-1" class="panel-collapse collapse">
	    	<div class="panel-body">
	        	Vivamus eros tortor, consequat sed posuere non, tempus non ligula. Integer pharetra sem eu dolor rhoncus euismod.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
  	<!-- Accordion Item -->
  	<div class="panel panel-default">
	    <div class="panel-heading">
	      	<h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-4-1"><i></i>Etiam suscipit leo tincidunt mi volutpat?</a></h4>
	    </div>
	    <div id="collapse-4-1" class="panel-collapse collapse">
	    	<div class="panel-body">
	        	Etiam suscipit leo tincidunt mi volutpat commodo. Morbi tempor interdum dictum. In hac habitasse platea dictumst.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
</div>
<!-- // Accordion #2 Style END -->

{{component.accordions}}