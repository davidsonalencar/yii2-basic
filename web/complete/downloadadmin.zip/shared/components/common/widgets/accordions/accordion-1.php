<!-- Accordion Default -->
<div class="panel-group accordion" id="accordion">

	<!-- Accordion Item -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse-1">Collapsible Accordions</a></h4>
	    </div>
	    <div id="collapse-1" class="panel-collapse collapse">
	      	<div class="panel-body">
	        	Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
  	<!-- Accordion Item -->
  	<div class="panel panel-default">
	    <div class="panel-heading">
	    	<h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse-2">Collapsible Accordions</a></h4>
	    </div>
	    <div id="collapse-2" class="panel-collapse collapse">
	    	<div class="panel-body">
	        	Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
  	<!-- Accordion Item -->
  	<div class="panel panel-default">
	    <div class="panel-heading">
	    	<h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse-3">Collapsible Accordions</a></h4>
	    </div>
	    <div id="collapse-3" class="panel-collapse collapse in">
	    	<div class="panel-body">
	        	Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird.
	      	</div>
	    </div>
  	</div>
  	<!-- // Accordion Item END -->
  	
</div>
<!-- // Accordion Default END -->

{{component.accordions}}