<!-- Links widget preview & code sample -->
<div class="menubar links primary">
	<ul>
		<li>Link widget:</li>
		<li><a href="">Button 1</a></li>
		<li class="divider"></li>
		<li><a href="">Button 2</a></li>
		<li class="divider"></li>
		<li><a href="">Button 3</a></li>
	</ul>
</div>
{{component.menubar}}