<!-- Button widget preview & code sample -->
<div class="menubar">
	<ul>
		<li>Button widget:</li>
		<li><a href="">Button 1</a></li>
		<li class="divider"></li>
		<li><a href="">Button 2</a></li>
		<li class="divider"></li>
		<li><a href="">Export</a></li>
	</ul>
</div>
{{component.menubar}}