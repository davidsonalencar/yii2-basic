<!-- Alert -->
<div class="alert alert-primary">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<strong>Warning!</strong> Best check yo self, you're not looking
	too good.
</div>
<!-- // Alert END -->

{{component.alerts}}