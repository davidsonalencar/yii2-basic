{{less.labels}}
<!-- Labels & Badges -->
	<div class="widget widget-heading-simple widget-body-simple">
		<div class="widget-head"><h4 class="heading glyphicons show_thumbnails"><i></i>Labels &amp; Badges</h4></div>
		<div class="widget-body">
			<table class="table table-bordered table-striped table-white">
				<thead>
					<tr>
						<th>Type</th>
						<th>Badges</th>
						<th>Labels</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Default</td>
						<td class="relativeWrap"><span class="badge">1</span></td>
						<td class="relativeWrap"><span class="label label-default">Default</span></td>
					</tr>
					<tr>
						<td>Success</td>
						<td class="relativeWrap"><span class="badge badge-success">2</span></td>
						<td class="relativeWrap"><span class="label label-success">Success</span></td>
					</tr>
					<tr>
						<td>Warning</td>
						<td class="relativeWrap"><span class="badge badge-warning">4</span></td>
						<td class="relativeWrap"><span class="label label-warning">Warning</span></td>
					</tr>
					<tr>
						<td>Important</td>
						<td class="relativeWrap"><span class="badge badge-danger">6</span></td>
						<td class="relativeWrap"><span class="label label-danger">Danger</span></td>
					</tr>
					<tr>
						<td>Info</td>
						<td class="relativeWrap"><span class="badge badge-info">8</span></td>
						<td class="relativeWrap"><span class="label label-info">Info</span></td>
					</tr>
					<tr>
						<td>Inverse</td>
						<td class="relativeWrap"><span class="badge badge-inverse">10</span></td>
						<td class="relativeWrap"><span class="label label-inverse">Inverse</span></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- // Labels & Badges END -->