<!-- Table -->
<table class="dynamicTable ajax table table-primary">

	<!-- Table heading -->
	<thead>
		<tr>
			<th>Rendering eng.</th>
			<th>Browser</th>
			<th>Platform(s)</th>
			<th>Eng. vers.</th>
			<th>CSS grade</th>
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody></tbody>
	<!-- // Table body END -->
	
</table>
<!-- // Table END -->

{{component.datatables}}
{{component.bootstrap-select}}