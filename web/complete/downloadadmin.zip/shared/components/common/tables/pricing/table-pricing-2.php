<!-- Pricing table -->
<table class="table table-vertical-center table-pricing table-pricing-2">

	<!-- Table heading -->
	<thead>
		<tr>
			<th class="center">Free Plan</th>
			<th class="center">Bronze Plan</th>
			<th class="center">Silver Plan</th>
			<th class="center">Gold Plan</th>
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
	
		<!-- Table pricing row -->
		<tr class="pricing">
			<td class="center">
				<span class="price">&dollar;0.00</span>
				<span>per month</span>
			</td>
			<td class="center">
				<span class="price">&dollar;9.99</span>
				<span>per month</span>
			</td>
			<td class="center">
				<span class="price">&dollar;19.99</span>
				<span>per month</span>
			</td>
			<td class="center">
				<span class="price">&dollar;49.99</span>
				<span>per month</span>
			</td>
		</tr>
		<!-- // Table pricing row END -->
		
		<!-- Table row -->
		<tr>
			<td class="center">
				Setup &amp; Installation<br/>
				HTML Templates<br/>
				SMS Templates<br/>
				API Included<br/>
				Tracking system
				<div class="separator bottom"></div>
				<button class="btn btn-primary">Sign up</button>
			</td>
			<td class="center">
				Setup &amp; Installation<br/>
				HTML Templates<br/>
				SMS Templates<br/>
				API Included<br/>
				Tracking system
				<div class="separator bottom"></div>
				<button class="btn btn-primary">Sign up</button>
			</td>
			<td class="center">
				Setup &amp; Installation<br/>
				HTML Templates<br/>
				SMS Templates<br/>
				API Included<br/>
				Tracking system
				<div class="separator bottom"></div>
				<button class="btn btn-primary">Sign up</button>
			</td>
			<td class="center">
				Setup &amp; Installation<br/>
				HTML Templates<br/>
				SMS Templates<br/>
				API Included<br/>
				Tracking system
				<div class="separator bottom"></div>
				<button class="btn btn-primary">Sign up</button>
			</td>
		</tr>
		<!-- // Table row END -->
		
	</tbody>
	<!-- // Table body END -->
	
</table>
<!-- // Pricing table END -->

{{component.tables-pricing}}