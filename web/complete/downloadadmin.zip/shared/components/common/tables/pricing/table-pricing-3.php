<div class="table-pricing-3">
	<ul class="list-unstyled row">
		<li class="col-md-4">
			<div class="innerAll">
				<h3>Starter</h3>
				<div class="body">
					<div class="price">
						Free
					</div>
				</div>
				<div class="features">
					<ul>
						<li>Basic Support</li>
						<li>Unlimited Email Alerts</li>
						<li>Free Weekly Digests</li>
						<li><strong>5 Email</strong> Templates</li>
						<li>Customizable Profile Page</li>
						<li><strong>2 months</strong> listing</li>
					</ul>
				</div>
				<div class="footer">
					<a href="#" class="btn btn-success">Get Started</a>
				</div>
			</div>
		</li>
		<li class="col-md-4 active">
			<div class="innerAll">
				<h3>Silver</h3>
				<div class="body">
					<div class="price">
						<span class="figure">&euro;19.99</span>
						<span class="term">per month</span>
					</div>
				</div>
				<div class="features">
					<ul>
						<li>Dedicated Support</li>
						<li>Unlimited Email Alerts</li>
						<li>Free Weekly Digests</li>
						<li><strong>20 Email</strong> Templates</li>
						<li>Customizable Profile Page</li>
						<li><strong>6 months</strong> listing</li>
					</ul>
				</div>
				<div class="footer">
					<a href="#" class="btn btn-success">Get Started</a>
				</div>
			</div>
		</li>
		<li class="col-md-4">
			<div class="innerAll">
				<h3>Gold</h3>
				<div class="body">
					<div class="price">
						<span class="figure">&euro;49</span>
						<span class="term">per month</span>
					</div>
				</div>
				<div class="features">
					<ul>
						<li>Premium Support</li>
						<li>Unlimited Email Alerts</li>
						<li>Free Weekly Digests</li>
						<li><strong>50 Email</strong> Templates</li>
						<li>Customizable Profile Page</li>
						<li><strong>Lifetime</strong> listing</li>
					</ul>
				</div>
				<div class="footer">
					<a href="#" class="btn btn-success">Get Started</a>
				</div>
			</div>
		</li>
		<div class="clearfix"></div>
	</ul>
</div>

{{component.tables-pricing}}