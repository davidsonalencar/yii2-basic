<div class="widget">
	<div class="widget-head">
		<h4 class="heading">Example Using jQuery</h4>
	</div>
	<div class="widget-body innerAll inner-2x">

		<!-- Table -->
		<table class="footable table table-striped table-primary">

			<!-- Table heading -->
			<thead>
				<tr>
					<th data-class="expand">Rendering eng.</th>
					<th data-hide="phone,tablet">Browser</th>
					<th data-hide="phone,tablet">Platform(s)</th>
					<th data-hide="phone">Eng. vers.</th>
					<th>CSS grade</th>
				</tr>
			</thead>
			<!-- // Table heading END -->
			
			<!-- Table body -->
			<tbody>
			
				<!-- Table row -->
				<tr class="gradeX">
					<td>Trident</td>
					<td>Internet Explorer 4.0</td>
					<td>Win 95+</td>
					<td class="center">4</td>
					<td class="center">X</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeC">
					<td>Trident</td>
					<td>Internet Explorer 5.0</td>
					<td>Win 95+</td>
					<td class="center">5</td>
					<td class="center">C</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Trident</td>
					<td>Internet Explorer 5.5</td>
					<td>Win 95+</td>
					<td class="center">5.5</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Trident</td>
					<td>Internet Explorer 6</td>
					<td>Win 98+</td>
					<td class="center">6</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Trident</td>
					<td>Internet Explorer 7</td>
					<td>Win XP SP2+</td>
					<td class="center">7</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Trident</td>
					<td>AOL browser (AOL desktop)</td>
					<td>Win XP</td>
					<td class="center">6</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Gecko</td>
					<td>Firefox 1.0</td>
					<td>Win 98+ / OSX.2+</td>
					<td class="center">1.7</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Gecko</td>
					<td>Firefox 1.5</td>
					<td>Win 98+ / OSX.2+</td>
					<td class="center">1.8</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Gecko</td>
					<td>Firefox 2.0</td>
					<td>Win 98+ / OSX.2+</td>
					<td class="center">1.8</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
				<!-- Table row -->
				<tr class="gradeA">
					<td>Gecko</td>
					<td>Firefox 3.0</td>
					<td>Win 2k+ / OSX.3+</td>
					<td class="center">1.9</td>
					<td class="center">A</td>
				</tr>
				<!-- // Table row END -->
				
			</tbody>
			<!-- // Table body END -->
			
		</table>
		<!-- // Table END -->

	</div>
</div>

{{component.tables-responsive-footable}}