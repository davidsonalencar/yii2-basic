<div class="row margin-none email">
	<div class="col-md-2 col-sm-12 padding-none">
		<ul class="list-group list-group-1 borders-none">
		  	<li class="active list-group-item">
		    	<a href=""><span class="badge badge-primary pull-right">5</span> <i class="fa fa-inbox"></i> Inbox</a>
		  	</li>
		    <li class="list-group-item">
		    	<a href=""><span class="badge badge-primary pull-right">2</span> <i class="fa fa-save"></i> Drafts</a>
		  	</li>
	    	<li class="list-group-item">
		     	<a href=""><i class="fa fa-upload"></i> Sent</a>
		  	</li>
		    <li class="list-group-item">
		    	<a href=""><i class="fa fa-cog"></i>  Settings</a>
		  	</li>
		</ul>
	</div>	

	<div class="col-md-4 col-sm-3 padding-none">
		<div class="widget">
			<div class="innerAll border-bottom">
				<div class="label label-default">INBOX</div> You have <strong class="text-primary">5 new</strong> emails
			</div>
			<div class="widget-body padding-none ">
				<div class="list-group email-item-list">
					<a href="#" class="list-group-item active">
					  	<span class="label label-inverse pull-right">27 Oct</span>
					    <h4 class="list-group-item-heading">MosaicPRO <i class="fa fa-flag text-primary"></i></h4>
					    <p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero</p>
					</a>
					<a href="#" class="list-group-item ">
				  		<span class="label label-inverse pull-right">16 Sep</span>
				    	<h4 class="list-group-item-heading">Adrian <i class="fa fa-flag text-primary"></i></h4>
				    	<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero</p>
				  	</a>
					<a href="#" class="list-group-item ">
				  		<span class="label label-inverse pull-right">19 Aug</span>
				    	<h4 class="list-group-item-heading">Mr.Awesome <i class="fa fa-bookmark-empty text-primary"></i> <i class="fa fa-briefcase text-regular"></i></h4>
				    	<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero</p>
				  	</a>
				    <a href="#" class="list-group-item ">
				  		<span class="label label-inverse pull-right">5 Aug</span>
					    <h4 class="list-group-item-heading">MosaicPRO <i class="fa fa-flag text-primary"></i></h4>
					    <p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero</p>
				  	</a>
			
					<a href="#" class="list-group-item ">
					  	<span class="label label-inverse pull-right">1 Jul</span>
					    <h4 class="list-group-item-heading">Adrian</h4>
					    <p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero</p>
				  	</a>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-sm-9 border-top padding-none">
		<div class="email-content innerAll">
			<div class="action">
				<a href="#" class="btn btn-default btn-sm"><i class="fa fa-reply"></i></a><a href="#" class="btn btn-default btn-sm"><i class="fa fa-forward"></i></a><a href="#" class="btn btn-primary btn-sm "><i class="fa fa-times"></i></a>
			</div>
			<div class="from">
				<a href="#">Adrian Demian</a> <span>(contact@mosaicpro.biz)</span>
				<div class="clearfix"></div>
				<span>To: your@email.com</span>
			</div>
			<strong>Subject Line Goes Here</strong>		
		</div>	
		
		<div class="innerAll">
			<p>Hi Adrian,</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, libero corporis ipsam voluptatibus suscipit eos expedita sapiente omnis voluptatum ea! Culpa, vitae eaque quis modi voluptatum quisquam ullam. Modi, tempora!</p>
			<p>Regards,<br/>mosaicpro </br>Director @ mosaicpro.biz</br>www.mosaicpro.biz</p>
		</div>
	</div>
</div>

{{component.email}}
{{component.list-group}}