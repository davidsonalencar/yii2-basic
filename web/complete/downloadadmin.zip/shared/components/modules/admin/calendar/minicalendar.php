<!-- Widget -->
<div class="widget widget-body-gray">
		
	<!-- Widget Heading -->
	<div class="widget-head">
		<h4 class="heading glyphicons calendar"><i></i>Mini Calendar</h4>
	</div>
	<!-- // Widget Heading END -->
	
	<div class="widget-body innerAll inner-2x">
		{{php.bootstrap-datepicker-inline}}
	</div>
</div>
<!-- // Widget END -->

{{ignore.docs}}