{{component.page-tour}}

<!-- Heading -->
<div class="heading-buttons">
	<h3>Page Tour Component</h3>
	<div class="buttons pull-right">
		<span class="btn btn-primary btn-icon glyphicons magic" id="tour-demo-start"><i></i>Start Demo Tour</span>
	</div>
	<div class="clearfix"></div>
</div>
<div class="separator bottom"></div>
<!-- // Heading END -->

<div class="innerLR">
	
	<!-- 2 Column / Half -->
	<div class="widget widget-heading-simple widget-body-gray" id="tour-step-1">
		
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Step 1: 2 Column / Half</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- 2 Column Grid / Half -->
			<div class="row">
			
				<!-- Half Column -->
				<div class="col-md-6">
					<h4>Half Column</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting
						industry. Lorem Ipsum has been the industry's standard dummy text
						ever since the 1500s, when an unknown printer took a galley of type
						and scrambled it to make a type specimen book.</p>
				</div>
				<!-- // Half Column END -->
				
				<!-- Half Column -->
				<div class="col-md-6">
					<h4>Half Column</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting
						industry. Lorem Ipsum has been the industry's standard dummy text
						ever since the 1500s, when an unknown printer took a galley of type
						and scrambled it to make a type specimen book.</p>
				</div>
				<!-- // Half Column END -->
				
			</div>
			<!-- // 2 Column Grid / Half END -->
		
		</div>
	</div>
	<!-- // 2 Column / Half END -->
	
	<!-- 3 Column / One Third -->
	<div class="widget widget-heading-simple widget-body-white" id="tour-step-2">
		
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Step 2: 3 Column / One Third</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- 3 Column Grid / One Third -->
			<div class="row">
			
				<!-- One Third Column -->
				<div class="col-md-4">
					<h4>One Third Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Third Column END -->
				
				<!-- One Third Column -->
				<div class="col-md-4">
					<h4>One Third Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Third Column END -->
				
				<!-- One Third Column -->
				<div class="col-md-4">
					<h4>One Third Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Third Column END -->
				
			</div>
			<!-- // 3 Column Grid / One Third END -->

		</div>
	</div>
	<!-- // 3 Column / One Third END -->
	
	<!-- 2 Column / One Third & Two Third -->
	<div class="widget widget-heading-simple widget-body-gray" id="tour-step-3">
		
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Step 3: 2 Column / One Third &amp; Two Third</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- 2 Column Grid / One Third & Two Third -->
			<div class="row">
				
				<!-- One Third Column -->
				<div class="col-md-4">
					<h4>One Third Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s.</p>
				</div>
				<!-- // One Third Column END -->
				
				<!-- Two Third Column -->
				<div class="col-md-8">
					<h4>Two Third Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // Two Third Column END -->
				
			</div>
			<!-- // 2 Column Grid / One Third & Two Third END -->

		</div>
	</div>
	<!-- // 2 Column / One Third & Two Third END -->
	
	<!-- 4 Column / One Fourth -->
	<div class="widget widget-heading-simple widget-body-white" id="tour-step-4">
	
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Step 4: 4 Column / One Fourth</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- 4 Column Grid / One Fourth -->
			<div class="row">
			
				<!-- One Fourth Column -->
				<div class="col-md-3">
					<h4>One Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Fourth Column END -->
				
				<!-- One Fourth Column -->
				<div class="col-md-3">
					<h4>One Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Fourth Column END -->
				
				<!-- One Fourth Column -->
				<div class="col-md-3">
					<h4>One Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Fourth Column END -->
				
				<!-- One Fourth Column -->
				<div class="col-md-3">
					<h4>One Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // One Fourth Column END -->
				
			</div>
			<!-- // 4 Column Grid / One Fourth END -->

		</div>
	</div>
	<!-- // 4 Column / One Fourth END -->
	
	<!-- 2 Column / One Fourth & Three Fourth -->
	<div class="widget widget-heading-simple widget-body-gray" id="tour-step-5">
		
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Step 5: 2 Column / One Fourth &amp; Three Fourth</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- 2 Column Grid / One Fourth & Three Fourth -->
			<div class="row">
			
				<!-- One Fourth Column -->
				<div class="col-md-3">
					<h4>One Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry.</p>
				</div>
				<!-- // One Fourth Column END -->
				
				<!-- Three Fourth Column -->
				<div class="span9">
					<h4>Three Fourth Column</h4>
					<p>Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the
						industry's standard dummy text ever since the 1500s, when an unknown
						printer took a galley of type and scrambled it to make a type
						specimen book.</p>
				</div>
				<!-- // Three Fourth Column END -->
				
			</div>
			<!-- // 2 Column Grid / One Fourth & Three Fourth -->

		</div>
	</div>
	<!-- // 2 Column / One Fourth & Three Fourth END -->
	
</div>

<script>
var pageGuideTarget = '#content';
</script>

<!-- Tour DEMO -->
<ul id="tlyPageGuide" data-tourtitle="My Tour" class="hidden-print">

	<!-- Tour Item -->
	<li class="tlypageguide_left" data-tourtarget="#tour-step-1 .col-md-6:last">
		<div>
			<h4>Step 1: 2 Column / Half</h4>
			<p>Here is the item description. The number will appear to the left of the element.</p>
		</div>
	</li>
	<!-- // Tour Item END -->
	
	<!-- Tour Item -->
	<li class="tlypageguide_right" data-tourtarget="#tour-step-2 .heading">
		<div>
			<h4>Step 2: 3 Column / One Third</h4>
			<p>Here is the item description. The number will appear to the right of the element.</p>
		</div>
	</li>
	<!-- // Tour Item END -->
	
	<!-- Tour Item -->
	<li class="tlypageguide_top" data-tourtarget="#tour-step-3 .heading">
		<div>
			<h4>Step 3: 2 Column / One Third &amp; Two Third</h4>
			<p>Here is the item description. The number will appear above the element.</p>
		</div>
	</li>
	<!-- // Tour Item END -->
	
	<!-- Tour Item -->
	<li class="tlypageguide_bottom" data-tourtarget="#tour-step-4 .col-md-3:eq(2)">
		<div>
			<h4>Step 4: 4 Column / One Fourth</h4>
			<p>Here is the item description. The number will appear under the element.</p>
		</div>
	</li>
	<!-- // Tour Item END -->
	
	<!-- Tour Item -->
	<li class="tlypageguide_right" data-tourtarget="#tour-step-5 .heading">
		<div>
			<h4>Step 5: 2 Column / One Fourth &amp; Three Fourth</h4>
			<p>Here is the item description. The number will appear to the right of the element.</p>
		</div>
	</li>
	<!-- // Tour Item END -->
	
</ul>
<!-- // Tour DEMO END -->