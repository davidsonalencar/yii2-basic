<div class="widget widget-heading-simple widget-body-gray">
	<div class="widget-body">
		<div class="row">
			<div class="col-md-4 center">
				<label class="strong">Search for</label>
				<input type="text" class="form-control" placeholder="Type your keywords .. " />
				
				<div class="separator top"></div>
				<label class="strong">Options</label>
				<div class="uniformjs">
					<label class="checkbox" style="display: inline-block;">
						<input type="checkbox" class="checkbox" value="1" />
						Sexxxxy
					</label>
					<label class="checkbox" style="display: inline-block; margin-left: 10px; margin-top: 10px;">
						<input type="checkbox" class="checkbox" value="1" checked="checked" />
						Checked
					</label>
				</div>
			</div>
			<div class="col-md-4 center">
				<label class="strong">Date from</label>
				<div class="input-group date" id="datepicker1">
				    <input class="form-control" type="text" value="14 February 2013">
				    <span class="input-group-addon"><i class="fa fa-th"></i></span>
				</div>
				<div class="separator top"></div>

				<label class="strong">Date to</label>
				<div class="input-group date" id="datepicker2">
				    <input class="form-control" type="text" value="14 February 2013">
				    <span class="input-group-addon"><i class="fa fa-th"></i></span>
				</div>
			</div>
			<div class="col-md-4 center">
				<label class="strong">Other options</label><br/>
				<div class="btn-group" data-toggle="buttons-checkbox">
				    <button type="button" class="active btn btn-inverse">Left</button>
				    <button type="button" class="active btn btn-inverse">Middle</button>
				    <button type="button" class="btn btn-inverse">Right</button>
				</div>
				<div class="separator bottom"></div>
				<button type="submit" class="btn btn-primary btn-large btn-block" data-loading-text="Now searching ..." data-toggle="btn-loading"><i class="fa fa-search"></i> Start Searching</button>
			</div>
		</div>
	</div>
</div>

<div class="widget widget-heading-simple widget-body-white margin-none">
	<div class="widget-body">
		<h5 class="text-uppercase strong separator bottom">30 Search results</h5>
		
		
		<div class="panel-group accordion accordion-2" id="tabAccountAccordion">

		    <!-- Accordion Item -->
		    <div class="panel panel-default">
		        <div class="panel-heading">
		            <h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-1-1"><i></i>Lorem ipsum dolor sit amet?</a></h4>
		        </div>
		        <div id="collapse-1-1" class="panel-collapse collapse">
		            <div class="panel-body">
		            	<div class="row">	
							<div class="col-md-2 center">
								<a href="" class="thumb"><img data-src="holder.js/150x100" alt="Image" class="img-responsive" /></a>
							</div>
							<div class="col-md-10">
								<h5 class="strong text-uppercase">What is Lorem Ipsum?</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
								<p class="margin-none strong"><a href="" class="glyphicons single chevron-right"><i></i>read more</a></p>
							</div>
						</div>
					</div>
		        </div>
		    </div>
		    <!-- // Accordion Item END -->
		
		    <!-- Accordion Item -->
		    <div class="panel panel-default">
		        <div class="panel-heading">
		            <h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-2-1"><i></i>Quisque porttitor elit ac mauris?</a></h4>
		        </div>
		        <div id="collapse-2-1" class="panel-collapse collapse in">
		            <div class="panel-body">
		            	<div class="row">	
							<div class="col-md-2 center">
								<a href="" class="thumb"><img data-src="holder.js/150x100" alt="Image" class="img-responsive" /></a>
							</div>
							<div class="col-md-10">
								<h5 class="strong text-uppercase">What is Lorem Ipsum?</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
								<p class="margin-none strong"><a href="" class="glyphicons single chevron-right"><i></i>read more</a></p>
							</div>
						</div>
					</div>
		        </div>
		    </div>
		    <!-- // Accordion Item END -->
		
		    <!-- Accordion Item -->
		    <div class="panel panel-default">
		        <div class="panel-heading">
		            <h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-3-1"><i></i>Vivamus eros tortor consequat sed?</a></h4>
		        </div>
		        <div id="collapse-3-1" class="panel-collapse collapse">
		            <div class="panel-body">
		            	<div class="row">	
							<div class="col-md-2 center">
								<a href="" class="thumb"><img data-src="holder.js/150x100" alt="Image" class="img-responsive" /></a>
							</div>
							<div class="col-md-10">
								<h5 class="strong text-uppercase">What is Lorem Ipsum?</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
								<p class="margin-none strong"><a href="" class="glyphicons single chevron-right"><i></i>read more</a></p>
							</div>
						</div>
					</div>
		        </div>
		    </div>
		    <!-- // Accordion Item END -->
		
		    <!-- Accordion Item -->
		    <div class="panel panel-default">
		        <div class="panel-heading">
		            <h4 class="panel-title"><a class="accordion-toggle glyphicons right_arrow" data-toggle="collapse" data-parent="#tabAccountAccordion" href="#collapse-4-1"><i></i>Etiam suscipit leo tincidunt mi volutpat?</a></h4>
		        </div>
		        <div id="collapse-4-1" class="panel-collapse collapse">
		            <div class="panel-body">
		            	<div class="row">	
							<div class="col-md-2 center">
								<a href="" class="thumb"><img data-src="holder.js/150x100" alt="Image" class="img-responsive" /></a>
							</div>
							<div class="col-md-10">
								<h5 class="strong text-uppercase">What is Lorem Ipsum?</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
								<p class="margin-none strong"><a href="" class="glyphicons single chevron-right"><i></i>read more</a></p>
							</div>
						</div>
					</div>
		        </div>
		    </div>
		    <!-- // Accordion Item END -->
		
		</div>
		<div class="separator bottom"></div>
		<ul class="pagination margin-none">
	        <li class="disabled"><a href="#">&lt;</a></li>
	        <li class="active"><a href="#">1</a></li>
	        <li><a href="#">2</a></li>
	        <li><a href="#">3</a></li>
	        <li><a href="#">&gt;</a></li>
	    </ul>
	</div>
</div>

{{component.bootstrap-datepicker}}
{{component.uniformjs}}
{{component.accordions}}
{{less.pagination}}
{{less.widgets}}
{{less.buttons}}
{{less.gallery}}
{{js.holder}}