<div class="widget widget-heading-simple widget-body-simple text-right">
	<form class="input-group">
	  	<input type="text" class="form-control" placeholder="Type your keywords .. " />
	  	<span class="input-group-btn"><button type="submit" class="btn btn-inverse">Search</button></span>
	</form>
</div>
<div class="widget widget-heading-simple widget-body-white margin-none">
	<div class="widget-body">
		<h5 class="text-uppercase strong">30 Search results</h5>
		<hr class="separator" />
		<table class="table table-vertical-center">
			<thead>
				<tr>
					<th class="center">Photo</th>
					<th class="center">Full name</th>
					<th class="center">Location</th>
					<th class="center">Membership</th>
					<th class="center">Actions</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
					<td class="strong center">Lorem Ipsum Dolor</td>
					<td class="center">Romania <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
					<td class="center"><span class="label label-success"><i class="fa fa-ok"></i> Accepted</span></td>
					<td class="center"><a href="" class="btn btn-xs btn-primary">View <i class="fa fa-eye-open"></i></a></td>
				</tr>
				<tr>
					<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
					<td class="strong center">John Doe</td>
					<td class="center">United States <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
					<td class="center"><span class="label label-success"><i class="fa fa-ok"></i> Accepted</span></td>
					<td class="center"><a href="" class="btn btn-xs btn-primary">View <i class="fa fa-eye-open"></i></a></td>
				</tr>
				<tr>
					<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
					<td class="strong center">Jane Doe</td>
					<td class="center">Europe <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
					<td class="center"><span class="label label-danger"><i class="fa fa-remove"></i> Rejected</span></td>
					<td class="center"><a href="" class="btn btn-xs btn-success">Accept <i class="fa fa-ok"></i></a></td>
				</tr>
				<tr>
					<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
					<td class="strong center">Lorem Dolor</td>
					<td class="center">Asia <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
					<td class="center"><span class="label label-danger"><i class="fa fa-remove"></i> Rejected</span></td>
					<td class="center"><a href="" class="btn btn-xs btn-success">Accept <i class="fa fa-ok"></i></a></td>
				</tr>
			</tbody>
		</table>
		
		<hr class="separator" />
		<ul class="pagination margin-none">
	        <li class="disabled"><a href="#">&lt;</a></li>
	        <li class="active"><a href="#">1</a></li>
	        <li><a href="#">2</a></li>
	        <li><a href="#">3</a></li>
	        <li><a href="#">&gt;</a></li>
	    </ul>
		
	</div>
</div>

{{less.tables}}
{{less.pagination}}
{{less.widgets}}
{{less.buttons}}
{{less.gallery}}
{{less.forms}}
{{less.labels}}
{{js.holder}}