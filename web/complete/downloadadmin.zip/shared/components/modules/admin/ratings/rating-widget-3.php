<div class="widget widget-body-white">
	<div class="widget-head"><h4 class="heading text-uppercase">Users</h4></div>
	<div class="widget-body padding-none">
		<table class="table table-striped table-vertical-center margin-none">
			<tbody>
				<tr>
					<td class="text-faded center strong border-none">4</td>
					<td class="text-primary border-none">mosaicpro</td>
					<td class="text-right">
						<a href=""><i class="fa fa-thumbs-up"></i></a>
						<a href=""><i class="fa fa-thumbs-down"></i></a>
					</td>
				</tr>
				<!-- <tr>
					<td class="text-faded center strong">3</td>
					<td class="text-primary">some dude</td>
					<td class="text-right">
						<a href=""><i class="fa fa-thumbs-up"></i></a>
						<a href=""><i class="fa fa-thumbs-down"></i></a>
					</td>
				</tr> -->
				<tr>
					<td class="text-faded center strong">2</td>
					<td class="text-primary">themeyard</td>
					<td class="text-right">
						<a href=""><i class="fa fa-thumbs-up"></i></a>
						<a href=""><i class="fa fa-thumbs-down"></i></a>
					</td>
				</tr>
				<tr>
					<td class="text-faded center strong">1</td>
					<td class="text-primary">gonzales</td>
					<td class="text-right">
						<a href=""><i class="fa fa-thumbs-up"></i></a>
						<a href=""><i class="fa fa-thumbs-down"></i></a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

{{component.ratings}}
{{less.widgets}}