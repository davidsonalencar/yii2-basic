<div class="widget widget-heading-simple widget-body-white">
	<div class="widget-body padding-none">
		<div class="row row-merge">
			<div class="col-md-6">
				<h5 class="innerAll margin-none bg-gray border-bottom text-center strong muted text-uppercase"><i class="fa fa-fw fa-coffee text-faded"></i> Guest</h5>
				<div class="innerAll center inner-2x">
					<span class="text-xxlarge strong text-primary">4</span>
				</div>
			</div>
			<div class="col-md-6">
				<h5 class="innerAll margin-none bg-gray border-bottom text-center strong muted text-uppercase"><i class="fa fa-fw fa-beer text-faded"></i> Host</h5>
				<div class="innerAll center inner-2x muted">
					<span class="text-xxlarge strong">1</span>
				</div>
			</div>
		</div>
	</div>
</div>

{{component.ratings}}
{{less.widgets}}