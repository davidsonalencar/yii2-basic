<div class="widget">
    <div class="widget-head">
        <h4 class="heading">CSS Star rating</h4>
    </div>
	<div class="widget-body center innerAll inner-2x" data-height="111px">
		<div class="rating text-medium text-faded margin-top-none">
        	<span class="star"></span>
        	<span class="star"></span>
        	<span class="star"></span>
        	<span class="star active"></span>
        	<span class="star"></span>
        </div>
        <div class="separator bottom"></div>
		<p class="lead">Current rating: <strong>2/5</strong></p>
	</div>
</div>

{{component.ratings}}
{{less.widgets}}