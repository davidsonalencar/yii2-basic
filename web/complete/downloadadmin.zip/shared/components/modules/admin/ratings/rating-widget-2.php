<div class="widget widget-body-white">
	<div class="widget-head"><h4 class="heading text-uppercase">Icon ratings</h4></div>
	<div class="widget-body center innerAll inner-2x" data-height="111px">
		<span class="text-medium text-primary"><i class="fa fa-trophy"></i></span>
		<span class="text-medium text-primary"><i class="fa fa-trophy"></i></span>
		<span class="text-medium text-primary"><i class="fa fa-trophy"></i></span>
		<span class="text-medium text-faded"><i class="fa fa-trophy"></i></span>
		<span class="text-medium text-faded"><i class="fa fa-trophy"></i></span>
		<div class="separator bottom"></div>
		<p class="lead">Total rating: <strong>3.4</strong></p>
	</div>
</div>

{{component.ratings}}
{{less.widgets}}