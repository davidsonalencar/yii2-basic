
<table class="table table-white table-vertical-center margin-none table-striped footable">
	<thead>
		<tr>
			<th data-class="expand" class="center">Photo</th>
			<th data-hide="phone" class="center">Full name</th>
			<th data-hide="phone" class="center">Location</th>
			<th data-hide="phone,tablet" class="center">Rating</th>
			<th data-hide="phone" class="center">Bonus</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
			<td class="strong center">Lorem Ipsum Dolor</td>
			<td class="center">Romania <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
			<td class="center">
				<div class="rating text-medium text-faded read-only">
		        	<span class="star active"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        </div>
			</td>
			<td class="center"><span class="strong text-medium">5 <i class="fa fa-gift"></i></span></td>
		</tr>
		<tr>
			<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
			<td class="strong center">John Doe</td>
			<td class="center">United States <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
			<td class="center">
				<div class="rating text-medium read-only">
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star active"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        </div>
			</td>
			<td class="center"><span class="strong text-medium">4 <i class="fa fa-gift"></i></span></td>
		</tr>
		<tr>
			<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
			<td class="strong center">Jane Doe</td>
			<td class="center">Europe <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
			<td class="center">
				<div class="rating text-medium text-faded read-only">
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        </div>
			</td>
			<td class="center"><span class="strong text-medium text-faded">2 <i class="fa fa-gift"></i></span></td>
		</tr>
		<tr>
			<td class="center"><img data-src="holder.js/50x50/dark" alt="Image" /></td>
			<td class="strong center">Hulky Bean</td>
			<td class="center">On the Moon <a href="" class="innerL text-underline">view on map <i class="fa fa-map-marker"></i></a></td>
			<td class="center">
				<div class="rating text-medium text-faded read-only">
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        	<span class="star"></span>
		        </div>
			</td>
			<td class="center"><span class="strong text-medium text-faded">1 <i class="fa fa-gift"></i></span></td>
		</tr>
	</tbody>
</table>

{{component.rating-table}}
{{component.tables-responsive-footable}}
{{js.holder}}