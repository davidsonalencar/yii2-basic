<div class="widget activity-line small">
	<div class="widget-body padding-none">
		<div class="icon primary"><a class="glyphicons luggage"><i></i></a></div>
		<span><a href="">Background Colored</a> icon activity line</span>
		<a class="activity-action pull-right glyphicons chat"><i></i></a>
	</div>
</div>

{{component.social}}