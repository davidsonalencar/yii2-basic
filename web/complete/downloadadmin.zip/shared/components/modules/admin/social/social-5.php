<div class="widget activity-line">
	<div class="widget-body padding-none">
		<div class="row row-merge">

			<div class="col-md-3 ">
				<div class="color-widget dribble center">
					<span class="glyphicons-social dribbble social-big"><i></i></span>
				</div>				
			</div>
			<div class="col-md-9">
				<div class="innerAll muted">
					<a href="" class="pull-right"><div class="label label-primary"><em>FOLLOW</em></div></a>
					<a><h4 class="strong muted text-uppercase">Adrian Demian</h4></a>
					<ul class="fa-ul margin-bottom-none">
						<li><i class="fa fa-li fa-suitcase"></i> Working at <a href="http://www.mosaicpro.biz">MosaicPro</a></li>
						<li><i class="fa fa-li fa-certificate"></i> Adobe  Certification</li>
					</ul>
				</div>
			</div>

		</div>
	</div>
</div>

{{component.social}}