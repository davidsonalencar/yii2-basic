<div class="widget activity-line">
	<div class="widget-body padding-none">
		<div class="share">
			<textarea class="form-control" rows="3" placeholder="Share what you've been up to..."></textarea>
			<div class="share-buttons">
				<a href="#" class="glyphicons user"><i></i></span></a>
				<a href="#" class="glyphicons plus"><i></i></span></a>
				<a href="#" class="glyphicons envelope"><i></i></span></a>
				<a href="#" class="glyphicons-social facebook"><i></i></span></a>
				<a href="#" class="glyphicons-social twitter"><i></i></span></a>
			</div>	
			<a class="btn btn-primary  btn-sm pull-right">Submit</a>
		</div>
	</div>
</div>

{{component.social}}
{{less.buttons}}