<div class="widget activity-line medium">
	<div class="widget-body padding-none">
		<div class="color-widget primary" >
			<div class="icon inverse"><a class="glyphicons envelope"><i></i></a></div>
			<span><a href="">Combined Colors</a> both for icon and text activity line</span>
			<a class="activity-action pull-right glyphicons chat"><i></i></a>
		</div>
	</div>
</div>

{{component.social}}