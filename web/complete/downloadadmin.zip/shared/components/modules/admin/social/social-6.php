<div class="widget activity-line">
	<div class="widget-body padding-none">
		<div class="color-widget inverse center">
			<span class="glyphicons-social twitter social-big"><i></i></span>
		</div>
		<p class="center innerAll">Follow us on <a href="#">twitter</a> </p>
	</div>
</div>

{{component.social}}