<div id="news-featured-3" class="owl-carousel owl-theme">
	<div class="item"><a href=""><img src="http://1.s3.envato.com/files/47045067/net-191.jpg" alt="" class="img-responsive img-clean"></a></div>
	<div class="item"><a href=""><img src="http://0.s3.envato.com/files/6049440/Photo%20Camera%20Lens.jpg" alt="" class="img-responsive img-clean"></a></div>
</div>

{{js.owl.carousel.min}}
{{css.owl.carousel}}
{{css.owl.theme}}
{{less.courses-featured-1}}
{{js.courses-featured-1.init}}