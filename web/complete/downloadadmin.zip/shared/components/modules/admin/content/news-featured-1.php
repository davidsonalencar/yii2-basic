<div id="news-featured-1" class="owl-carousel owl-theme">
		<div class="item">
		<div class="row row-merge bg-white">
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti, voluptatum, distinctio eius aliquam sed ad consequatur debitis commodi at architecto est itaque laudantium sint tempora inventore alias qui libero accusantium?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
		</div>
	</div>
		<div class="item">
		<div class="row row-merge bg-white">
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti, voluptatum, distinctio eius aliquam sed ad consequatur debitis commodi at architecto est itaque laudantium sint tempora inventore alias qui libero accusantium?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
		</div>
	</div>
		<div class="item">
		<div class="row row-merge bg-white">
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti, voluptatum, distinctio eius aliquam sed ad consequatur debitis commodi at architecto est itaque laudantium sint tempora inventore alias qui libero accusantium?</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="innerAll inner-2x">
					<h4><a href="" class="text-primary">Best of Web Design in 2013</a></h4>
					<p class="text-muted">30/12/2013</p>
					<p class="margin-none">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, est, iste similique eius perspiciatis expedita exercitationem. Commodi, numquam repellendus neque adipisci cumque dicta rem. Tempore, tempora beatae unde ducimus. Blanditiis?</p>
				</div>
			</div>
		</div>
	</div>
	</div>

{{js.owl.carousel.min}}
{{css.owl.carousel}}
{{css.owl.theme}}
{{less.news-featured-1}}
{{js.news-featured-1.init}}