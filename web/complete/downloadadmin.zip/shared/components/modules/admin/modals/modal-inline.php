<!-- Modal inline -->
<div class="modal modal-inline">
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal heading -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Modal header</h4>
			</div>
			<!-- // Modal heading END -->
			
			<!-- Modal body -->
			<div class="modal-body">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
			</div>
			<!-- // Modal body END -->
			
			<!-- Modal footer -->
			<div class="modal-footer">
				<a href="#" class="btn btn-default">Just a button</a> 
				<a href="#modal-simple" data-toggle="modal" class="btn btn-primary">Open Live Modal</a>
			</div>
			<!-- // Modal footer END -->

		</div>
	</div>
	
</div>

<!-- Modal -->
<div class="modal fade" id="modal-simple">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal heading -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title">Modal header</h3>
			</div>
			<!-- // Modal heading END -->
			
			<!-- Modal body -->
			<div class="modal-body">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
			</div>
			<!-- // Modal body END -->
			
			<!-- Modal footer -->
			<div class="modal-footer">
				<a href="#" class="btn btn-default" data-dismiss="modal">Close</a> 
				<a href="#" data-dismiss="modal" class="btn btn-primary">Save changes</a>
			</div>
			<!-- // Modal footer END -->

		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}