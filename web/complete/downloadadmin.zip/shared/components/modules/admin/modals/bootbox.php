<div class="widget">
	<div class="widget-head">
		<h4 class="heading">Bootbox <span>Manage modals with JavaScript API</span></h4>
	</div>
	<div class="widget-body">
		<button id="modals-bootbox-alert" class="btn btn-primary">Alert</button>
		<button id="modals-bootbox-confirm" class="btn btn-primary">Confirm</button>
		<button id="modals-bootbox-prompt" class="btn btn-primary">Prompt</button>
		<button id="modals-bootbox-custom" class="btn btn-primary">Custom Dialog</button>
	</div>
</div>

{{component.modals}}
{{less.buttons}}