<!-- Main Sidebar Menu -->
<div id="menu" class="hidden-print hidden-xs">
<!-- // Main Sidebar Menu END -->
<div class="sidebar sidebar-SIDEBAR_STYLE">
		<div class="user-profile media innerAll">
			<a href="" class="pull-left"><img src="