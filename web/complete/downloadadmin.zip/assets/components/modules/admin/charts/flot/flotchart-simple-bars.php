<!-- Simple Chart -->
<div id="chart_simple_bars" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-simple-bars.init}}
{{builder.saveComponent.original}}