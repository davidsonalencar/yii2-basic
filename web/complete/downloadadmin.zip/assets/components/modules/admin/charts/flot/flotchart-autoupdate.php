<!-- Live Chart -->
<div id="chart_live" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-autoupdating.init}}
{{builder.saveComponent.original}}