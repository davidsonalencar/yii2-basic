<!-- Stacked bars Chart -->
<div id="chart_stacked_bars" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-bars-stacked.init}}
{{builder.saveComponent.original}}