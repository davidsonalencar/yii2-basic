<!-- Ordered bars Chart -->
<div id="chart_ordered_bars" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.jquery.flot.orderBars}}
{{js.flotchart-bars-ordered.init}}
{{builder.saveComponent.original}}