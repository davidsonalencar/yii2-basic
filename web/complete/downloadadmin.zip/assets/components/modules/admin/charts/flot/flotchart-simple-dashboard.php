<!-- Simple Chart -->
<div id="chart_simple" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-simple-dashboard.init}}
{{builder.saveComponent.original}}