<!-- Donut Chart -->
<div id="chart_donut" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.jquery.flot.pie}}
{{js.flotchart-donut.init}}
{{builder.saveComponent.original}}