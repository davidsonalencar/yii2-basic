<!-- Pie Chart -->
<div id="chart_pie" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.jquery.flot.pie}}
{{js.flotchart-pie.init}}
{{builder.saveComponent.original}}