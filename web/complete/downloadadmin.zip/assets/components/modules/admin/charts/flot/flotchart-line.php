<!-- Chart with lines and fill with no points -->
<div id="chart_lines_fill_nopoints" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-line.init}}
{{builder.saveComponent.original}}