<!-- Horizontal Bars Chart -->
<div id="chart_horizontal_bars" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-bars-horizontal.init}}
{{builder.saveComponent.original}}