<!-- Simple Chart -->
<div id="chart_simple" class="flotchart-holder"></div>

{{component.flotcharts}}
{{js.flotchart-simple.init}}
{{builder.saveComponent.original}}