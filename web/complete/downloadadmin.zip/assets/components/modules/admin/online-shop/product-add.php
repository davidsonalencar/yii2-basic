<!-- Widget -->
<div class="widget widget-tabs widget-tabs-gray">

	<!-- Widget heading -->
	<div class="widget-head">
		<ul>
			<li class="active"><a href="#productDescriptionTab" data-toggle="tab" class="glyphicons font"><i></i>