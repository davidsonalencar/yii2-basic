<div class="row">
	<!-- Row -->
	
		<!-- Column -->
		<div class="col-md-4">
		
			<!-- Widget -->
			<div class="widget widget-inverse">
				
				<!-- Widget heading -->
				<div class="widget-head">
					<h4 class="heading">Last order</h4>
					<a href="" class="details pull-right">view all</a>
				</div>
				<!-- // Widget heading END -->
				
				<div class="widget-body innerAll half">
					<ul class="unstyled">
						<li>
							<div class="media">
								<a class="pull-left thumb"><img data-src="holder.js/40x40/dark" class="media-object img-responsive" alt="40x40"></a>
								<div class="media-body">
									<p class="margin-none text-uppercase">10 items</p>
									<p><strong>&euro;5,900</strong></p>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<!-- // Widget END -->
			
		</div>
		<!-- // Column END -->
		
		<!-- Column -->
		<div class="col-md-4">
		
			<!-- Widget -->
			<div class="widget widget-inverse">
			
				<!-- Widget heading -->
				<div class="widget-head">
					<h4 class="heading">Best seller</h4>
					<a href="" class="details pull-right">view all</a>
				</div>
				<!-- // Widget heading END -->
				
				<div class="widget-body innerAll half">
					<ul class="unstyled">
						<li>
							<div class="media">
								<a class="pull-left thumb"><img data-src="holder.js/40x40/dark" class="media-object img-responsive" alt="40x40"></a>
								<div class="media-body">
									<p class="margin-none">Product name</p>
									<p><strong>&euro;2,900</strong></p>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<!-- // Widget END -->
			
		</div>
		<!-- // Column END -->
		
		<!-- Column -->
		<div class="col-md-4">
		
			<!-- Widget -->
			<div class="widget widget-inverse">
			
				<!-- Widget heading -->
				<div class="widget-head">
					<h4 class="heading">Promotion</h4>
					<a href="" class="details pull-right">view all</a>
				</div>
				<!-- // Widget heading END -->
				
				<div class="widget-body innerAll half">
					<ul class="unstyled">
						<li>
							<div class="media">
								<a class="pull-left thumb"><img data-src="holder.js/40x40/dark" class="media-object img-responsive" alt="40x40"></a>
								<div class="media-body">
									<p class="margin-none">Product name</p>
									<p><strong>&euro;1,800</strong></p>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<!-- // Widget END -->
			
		</div>
		<!-- // Column END -->
		
	
	<!-- // Row END -->
</div>

{{less.widgets}}
{{js.holder}}
{{less.gallery}}