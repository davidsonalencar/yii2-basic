<!-- Total products & Sort by options -->
<div class="form-inline separator bottom small">
	