<!-- Widget -->
<div class="widget widget-tabs widget-tabs-gray border-bottom-none">

	<!-- Widget heading -->
	<div class="widget-head">
		<ul>
			<li class="active"><a class="glyphicons edit" href="#account-details" data-toggle="tab"><i></i>