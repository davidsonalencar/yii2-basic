<div class="rating text-faded">
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star active"></span>
        <span class="star"></span>
</div>  

{{component.ratings}}
{{less.widgets}}