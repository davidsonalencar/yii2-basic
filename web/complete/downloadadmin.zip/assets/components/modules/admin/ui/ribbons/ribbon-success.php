<!-- Ribbon -->
<div class="ribbon-wrapper"><div class="ribbon success">50% Off</div></div>
{{component.ribbon}}
{{builder.exclude.children}}