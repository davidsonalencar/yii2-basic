<!-- Progress bars -->
<div class="widget widget-inverse">
	<div class="widget-head"><h4 class="heading glyphicons show_thumbnails"><i></i>Progress bars</h4></div>
	<div class="widget-body">
		<table class="table">
			<thead>
				<tr>
					<th class="shortRight">Styles</th>
					<th>Preview</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="shortRight">Default</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-default" style="width: 20%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Primary</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-primary" style="width: 30%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Success</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-success" style="width: 60%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Warning</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-warning" style="width: 55%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Danger</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-danger" style="width: 80%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Inverse</td>
					<td>
						<div class="progress">
							<div class="progress-bar progress-bar-inverse" style="width: 30%;"></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="shortRight">Mini</td>
					<td>
						<div class="progress progress-mini">
							<div class="progress-bar" style="width: 40%;"></div>
						</div>
						<div class="progress progress-mini">
							<div class="progress-bar progress-bar-danger" style="width: 55%;"></div>
						</div>
						<div class="progress progress-mini">
							<div class="progress-bar progress-bar-success" style="width: 80%;"></div>
						</div>
						<div class="progress progress-mini">
							<div class="progress-bar progress-bar-warning" style="width: 60%;"></div>
						</div>
						<div class="progress progress-mini">
							<div class="progress-bar progress-bar-primary" style="width: 75%;"></div>
						</div>
						<div class="progress progress-mini">
							<div class="progress-bar progress-bar-inverse" style="width: 50%;"></div>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<!-- // Progress bars END -->

{{less.progress-bars}}