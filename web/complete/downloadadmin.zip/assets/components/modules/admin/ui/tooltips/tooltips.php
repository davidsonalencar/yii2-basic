<!-- Tooltips -->
<div class="widget widget-inverse">
	
	<!-- Widget Heading -->
	<div class="widget-head">
		<h3 class="heading glyphicons show_thumbnails"><i></i>Tooltips</h3>
	</div>
	<!-- // Widget Heading END -->
	
	<div class="widget-body">
	
		<!-- Row -->
		<div class="row">
		
			<!-- Column -->
			<div class="col-md-6">
				<p class="muted">Tight pants next level keffiyeh <a href="#" data-toggle="tooltip" title="" data-original-title="Default tooltip">you probably</a> haven't heard of them. Photo booth beard raw denim letterpress vegan messenger bag stumptown. Farm-to-table seitan, mcsweeney's fixie sustainable quinoa 8-bit american apparel <a href="#" data-toggle="tooltip" title="" data-original-title="Another tooltip">have a</a> terry richardson vinyl chambray. Beard stumptown, cardigans banh mi lomo thundercats. Tofu biodiesel williamsburg marfa, four loko mcsweeney's cleanse vegan chambray. A really ironic artisan <a href="#" data-toggle="tooltip" title="" data-original-title="A much longer tooltip belongs right here to demonstrate the max-width we apply.">whatever keytar</a>, scenester farm-to-table banksy Austin <a href="#" data-toggle="tooltip" title="" data-original-title="The last tip!">twitter handle</a> freegan cred raw denim single-origin coffee viral.</p>
			</div>
			<!-- // Column END -->
			
			<!-- Column -->
			<div class="col-md-6">
				<div class="innerAll">
				
					<!-- Live DEMO Tooltip Options Table -->
					<table class="table table-bordered table-vertical-center">
						<tbody>
							<tr>
								<td class="center"><span class="btn btn-primary" data-toggle="tooltip" data-original-title="Tooltip on Left" data-placement="left">Tooltip on Left</span></td>
								<td class="center"><span class="btn btn-primary" data-toggle="tooltip" data-original-title="Tooltip on Top" data-placement="top">Tooltip on Top</span></td>
							</tr>
							<tr>
								<td class="center"><span class="btn btn-primary" data-toggle="tooltip" data-original-title="Tooltip on Right" data-placement="right">Tooltip on Right</span></td>
								<td class="center"><span class="btn btn-primary" data-toggle="tooltip" data-original-title="Tooltip on Bottom" data-placement="bottom">Tooltip on Bottom</span></td>
							</tr>
						</tbody>
					</table>
					<!-- // Live DEMO Tooltip Options Table END -->
					
				</div>
			</div>
			<!-- // Column END -->
			
		</div>
		<!-- // Row END -->	</div>
</div>
<!-- // Tooltips END -->

{{less.tooltips}}