<!-- Popovers -->
<div class="widget widget-inverse">
	
	<!-- Widget Heading -->
	<div class="widget-head">
		<h3 class="heading glyphicons show_thumbnails"><i></i>Popovers</h3>
	</div>
	<!-- // Widget Heading END -->
	
	<div class="widget-body">
	
		<!-- Row -->
		<div class="row">
		
			<!-- Column -->
			<div class="col-md-7" id="demo_popovers">
				
				<!-- Row -->
				<div class="row">
				
					<!-- Column -->
					<div class="col-md-6">
						<div class="inner">
						
							<!-- Popover Top -->
							<div class="popover top">
								<div class="arrow"></div>
								<h3 class="popover-title">Popover top</h3>
								<div class="popover-content">
									<p>Sed posuere consectetur est at lobortis. Aenean eu leo quam.
										Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
								</div>
							</div>
							<!-- // Popover Top END -->
							
						</div>
					</div>
					<!-- // Column END -->
					
					<!-- Column -->
					<div class="col-md-6">
						<div class="innerLR">
						
							<!-- Popover Right -->
							<div class="popover right">
								<div class="arrow"></div>
								<h3 class="popover-title">Popover right</h3>
								<div class="popover-content">
									<p>Sed posuere consectetur est at lobortis. Aenean eu leo quam.
										Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
								</div>
							</div>
							<!-- // Popover Right END -->
							
						</div>
					</div>
					<!-- // Column END -->
					
				</div>
				<!-- // Row END -->
				
				<!-- Row -->
				<div class="row">
				
					<!-- Column -->
					<div class="col-md-6">
						<div class="innerT">
						
							<!-- Popover Bottom -->
							<div class="popover bottom">
								<div class="arrow"></div>
								<h3 class="popover-title">Popover bottom</h3>
								<div class="popover-content">
									<p>Sed posuere consectetur est at lobortis. Aenean eu leo quam.
										Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
								</div>
							</div>
							<!-- // Popover Bottom END -->
							
						</div>
					</div>
					<!-- // Column END -->
					
					<!-- Column -->
					<div class="col-md-6">
						<div class="innerAll">
						
							<!-- Popover Left -->
							<div class="popover left">
								<div class="arrow"></div>
								<h3 class="popover-title">Popover left</h3>
								<div class="popover-content">
									<p>Sed posuere consectetur est at lobortis. Aenean eu leo quam.
										Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
								</div>
							</div>
							<!-- // Popover Left END -->
							
						</div>
					</div>
					<!-- // Column END -->
					
				</div>
				<!-- // Row END -->
				
			</div>
			<!-- // Column END -->
			
			<!-- Column -->
			<div class="col-md-5">
				<div class="inner">
				
					<!-- Live DEMO Popover Options Table -->
					<table class="table table-bordered table-vertical-center">
						<tbody>
							<tr>
								<td class="center"><span class="btn btn-inverse" data-toggle="popover" data-title="Popover on Left" data-content="Sed posuere consectetur est at lobortis. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum." data-placement="left">Popover on Left</span></td>
								<td class="center"><span class="btn btn-inverse" data-toggle="popover" data-title="Popover on Top" data-content="Sed posuere consectetur est at lobortis. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum." data-placement="top">Popover on Top</span></td>
							</tr>
							<tr>
								<td class="center"><span class="btn btn-inverse" data-toggle="popover" data-title="Popover on Right" data-content="Sed posuere consectetur est at lobortis. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum." data-placement="right">Popover on Right</span></td>
								<td class="center"><span class="btn btn-inverse" data-toggle="popover" data-title="Popover on Bottom" data-content="Sed posuere consectetur est at lobortis. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum." data-placement="bottom">Popover on Bottom</span></td>
							</tr>
						</tbody>
					</table>
					<div class="separator bottom"></div>
					<!-- // Live DEMO Popover Options Table END -->
				</div>
			</div>
			<!-- // Column END -->
			
		</div>
		<!-- // Row END -->
		
	</div>
</div>
<!-- // Popovers END -->

{{less.popovers}}