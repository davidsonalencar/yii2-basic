<!-- Ribbon -->
<div class="ribbon-wrapper"><div class="ribbon danger">50% Off</div></div>
{{component.ribbon}}
{{builder.exclude.children}}