<div class="innerB">
	<button class="btn btn-inverse filter active" data-filter="mixit-filter-1">Filter 1</button>
	<button class="btn btn-inverse filter" data-filter="mixit-filter-2">Filter 2</button>
	<button class="btn btn-inverse filter" data-filter="all">Show all</button>
</div>

<div class="mixitup">
	<div class="row">
					<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest active">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/59015141" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/1.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Publix Sprinkler</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/50522981" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/2.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">One More Beer!</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/54932277" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/3.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Spacebound: Models &amp; Props</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/4749536" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/4.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Alma</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest active">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/33670490" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/5.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">The Artists</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/8706167" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/6.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Les Dangereux</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/51478122" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/7.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Dum Spiro - HD</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/29573040" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/8.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">A Shadow of Blue</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/50540814" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/9.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">50 Jahre Orion</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/14989162" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/10.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">JOBS: THE BAKER</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-1 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/2480635" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/11.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Eatliz - Hey Animation</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
				<div class="mixit-filter-2 mix col-md-4">
	<div class="widget bg-none widget-pinterest">
		<div class="widget-body bg-none padding-none">
			<a href="http://vimeo.com/28355660" data-toggle="prettyPhoto" class="thumb overflow-hidden" data-height="150">
				<img src="http://demo.mosaicpro.biz/assets/media/video/12.jpg" alt="photo" />
			</a>
			<div class="description bg-white overflow-hidden" data-height="130">
				<h5 class="text-uppercase">Back to the Start</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, consequuntur iure commodi omnis at pariatur quis hic mollitia impedit error.</p>			</div>
		</div>
	</div>
	</div>
		</div>
</div>

{{component.widget-pinterest}}
{{component.gallery-video}}

{{less.mixitup}}
{{js.jquery.mixitup.min}}
{{js.mixitup.init}}