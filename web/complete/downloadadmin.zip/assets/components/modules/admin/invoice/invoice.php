<div id="pdfTarget">
	<div class="innerAll shop-client-products cart invoice">
	
		<h3 class="separator bottom">Invoice</h3>
		<table class="table table-invoice">
			<tbody>
				<tr>
					<td style="width: 58%;">
						<div class="media">
							<img class="media-object pull-left thumb" src="http://1.s3.envato.com/files/50438174/tf-avatar.jpg" alt="Logo" />
							<div class="media-body hidden-print">
								<div class="alert alert-primary">
									<strong>Note:</strong><br/>
									This page is optimized for print. Try print the invoice and check out the preview.
									For example, this note will not be visible.
								</div>
								<div class="separator bottom"></div>
							</div>
						</div>
					</td>
					<td class="right">
						<div class="innerL">
							<h4 class="separator bottom">#12345678 / 17 Aug 2014</h4>
							<button type="button" data-toggle="print" class="btn btn-default hidden-print"><i class="fa fa-fw fa-print"></i> Print invoice</button>
							<button type="button" data-toggle="button-loading pdf" data-target="#pdfTarget" class="btn btn-primary hidden-print"><i class="fa fa-fw fa-download"></i> Save as PDF</button>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		
		<div class="box-generic">
			<table class="table table-invoice">
				<tbody>
					<tr>
						<td style="width: 50%;">
							<p class="lead">Company information</p>
							<h2>Apple Inc.</h2>
							<address class="margin-none">
								<strong>1 Infinite Loop</strong><br/>
								Cupertino, CA 95014<br/>
								408.996.1010<br/>
								<abbr title="Work email">e-mail:</abbr> <a href="mailto:#">company@mybiz.com</a><br /> 
								<abbr title="Work Phone">phone:</abbr> (012) 345-678-901<br/>
								<abbr title="Work Fax">fax:</abbr> (012) 678-132-901
							</address>
						</td>
						<td class="right">
							<p class="lead">Client information</p>
							<h2>John Doe</h2>
							<address class="margin-none">
								<strong>Business manager</strong> at 
								<strong><a href="#">Business</a></strong><br> 
								<abbr title="Work email">e-mail:</abbr> <a href="mailto:#">john.doe@mybiz.com</a><br /> 
								<abbr title="Work Phone">phone:</abbr> (012) 345-678-901<br/>
								<abbr title="Work Fax">fax:</abbr> (012) 678-132-901
								<div class="separator line"></div>
								<p class="margin-none"><strong>Note:</strong><br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tristique rutrum libero, vel bibendum nunc.</p>
							</address>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		
		<div class="box-generic padding-none">
			<table class="table table-vertical-center bg-white margin-none">
				<thead class="bg-primary">
					<tr>
						<th style="width: 1%;" class="center">