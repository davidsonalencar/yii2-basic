<div class="widget widget-inverse">
	<div class="widget-head">
		<h4 class="heading"><i class="fa fa-sitemap fa-fw"></i> Mirror Timeline</h4>
	</div>
	<div class="widget-body padding-none">
		
		<div class="relativeWrap overflow-hidden">
		<div class="row row-merge layout-timeline layout-timeline-mirror">
			<div class="col-md-6"></div>
			<div class="col-md-6">
				<div class="innerAll">
					
					<ul class="timeline">
						<li class="active">
							<div class="separator bottom">
								<span class="date box-generic">Now</span>
								<span class="type glyphicons suitcase">Task <i></i><span class="time">08:00</span></span>
								<button type="button" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Add event</button>
							</div>
							<div class="widget widget-heading-simple widget-body-white margin-none">
								<div class="widget-body">
									<div class="media">
										<div class="media-object pull-left thumb"><img src="