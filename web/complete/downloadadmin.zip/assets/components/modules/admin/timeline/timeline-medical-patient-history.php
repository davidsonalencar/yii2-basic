<ul class="timeline-activity list-unstyled">
	<li>
		<i class="list-icon fa fa-scissors"></i>
		<div class="block">
			<div class="caret"></div>
			<div class="box-generic bg-primary-light">
				<div class="timeline-top-info border-bottom">
					<a href="" class="text-regular">Upcoming procedure</a> <span class="text-muted2">(consectetur adipisicing elit)</span> with <i class="fa fa-stethoscope text-primary"></i> <a href="">Dr. Dignissimos</a>
				</div>
				<div class="innerAll half inline-block">
					<i class="fa fa-clock-o text-primary"></i> 17:00 &nbsp;
					<i class="fa fa-calendar text-primary"></i> 3 October 2013
				</div>
			</div>
			<div class="separator bottom"></div>
		</div>
	</li>
	<li>
		<i class="list-icon fa fa-stethoscope"></i>
		<div class="block">
			<div class="caret"></div>
			<div class="box-generic">
				<div class="timeline-top-info border-bottom">
					<a href="" class="text-regular">Consultation</a> with <i class="fa fa-stethoscope"></i> <a href="">Dr. Dignissimos</a>
				</div>
				<div class="innerAll half inline-block">
					<i class="fa fa-clock-o"></i> 10:00 &nbsp;
					<i class="fa fa-calendar"></i> 2 October 2013
				</div>
			</div>
			<div class="separator bottom"></div>
		</div>
		<div class="block block-inline">
			<div class="box-generic">
				<div class="innerT innerR">
					<button class="btn btn-primary btn-xs pull-right"><i class="fa fa-download"></i></button>
					<div class="media inline-block margin-none">
						<div class="innerLR">
							<i class="fa fa-stethoscope pull-left text-primary fa-2x"></i>
							<div class="media-body">
								<div><a href="" class="strong text-regular">Lab Test Results</a></div>
								<span>1 MB</span>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="block block-inline">
			<div class="box-generic">
				<div class="innerT innerR">
					<button class="btn btn-primary btn-xs pull-right"><i class="fa fa-eye"></i></button>
					<div class="media inline-block margin-none">
						<div class="innerLR">
							<i class="fa fa-file-text-o pull-left text-primary fa-2x"></i>
							<div class="media-body">
								<div><a href="" class="strong text-regular">Notes</a></div>
								<span>24 KB</span>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</li>
</ul>

{{component.timeline}}