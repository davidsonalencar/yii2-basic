<ul class="timeline-activity list-unstyled">
	<li class="active">
		<i class="list-icon fa fa-share"></i>
		<div class="block block-inline">
			<div class="caret"></div>
			<div class="box-generic">
				<div class="timeline-top-info content-filled border-bottom">
					<i class="fa fa-user"></i> <a href="">Bill</a> got a review for <a href="" class="text-primary">FLAT PLUS UI Interface Design</a> from <a href="#"><img src="