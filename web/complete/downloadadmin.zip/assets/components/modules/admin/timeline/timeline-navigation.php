<div class="widget widget-inverse">
	<div class="widget-head">
		<h4 class="heading"><i class="fa fa-list fa-fw"></i> Timeline with Navigation</h4>
	</div>
	<div class="widget-body padding-none">
		
		<div class="row row-merge layout-timeline">
			<div class="col-md-4">
				<div class="innerAll">
				
					<div class="row margin-none innerT">
						<div class="col-md-7">
							<ul class="nav nav-pills nav-stacked nav-timeline">
								<li class="active"><a href="">Now</a></li>
								<li><a href="">Yesterday</a></li>
								<li><a href="">2 Weeks Ago</a></li>
								<li><a href="" class="glyphicons calendar">Custom<i></i></a></li>
							</ul>
						</div>
					</div>

				</div>
			</div>
			<div class="col-md-8">
				<div class="innerAll">
					
					<ul class="timeline">
						<li class="active">
							<div class="separator bottom">
								<span class="date box-generic">Now</span>
								<span class="type glyphicons suitcase">Task <i></i><span class="time">08:00</span></span>
								<button type="button" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Add event</button>
							</div>
							<div class="widget widget-heading-simple widget-body-white margin-none">
								<div class="widget-body">
									<div class="media">
										<div class="media-object pull-left thumb"><img src="