<!-- Widget -->
<div class="widget widget-inverse">
		
	<!-- Widget Heading -->
	<div class="widget-head">
		<h4 class="heading glyphicons calendar"><i></i>Mini Calendar</h4>
	</div>
	<!-- // Widget Heading END -->
	
	<div class="widget-body innerAll half">
		{{php.bootstrap-datepicker-inline}}
	</div>
</div>
<!-- // Widget END -->

{{ignore.docs}}