<div class="row">
	<div class="col-md-8">
	
		<!-- Widget -->
		<div class="widget">
			<div class="widget-body">
				<div data-component>
					<div id="calendar"></div>
					{{builder.saveComponent.original}}
				</div>
			</div>
		</div>
		<!-- // Widget END -->
	
	</div>
	<div class="col-md-4">
	
		<!-- External Events -->
		<div class="uniformjs" id="external-events">
		
			<!-- Widget -->
			<div class="widget widget-inverse">
			
				<!-- Widget heading -->
				<div class="widget-head">
					<h3 class="heading">Draggable Events</h3>
				</div>
				<!-- // Widget heading END -->
				
				<div class="widget-body">
				
					<!-- Events list -->
					<ul class="unstyled">
						<li class="glyphicons move"><i></i> My Event 1</li>
						<li class="glyphicons move"><i></i> My Event 2</li>
						<li class="glyphicons move"><i></i> My Event 3</li>
						<li class="glyphicons move"><i></i> My Event 4</li>
						<li class="glyphicons move"><i></i> My Event 5</li>
					</ul>
					<!-- Events list END -->
					
					<label for="drop-remove" class="checkbox">
						<input type="checkbox" class="checkbox" id="drop-remove" /> 
						remove after drop
					</label>
					<p>APP_NAME provides a full-sized, drag &amp; drop calendar. It uses AJAX to fetch events on-the-fly for each month and is easily configured to use your own feed format, plus there's an extension provided for Google Calendar.</p>
				</div>
			</div>
			<!-- // Widget END -->
			
			{{content}}
			{{component.uniformjs}}
			
		</div>
		<!-- // External Events END -->
		
	</div>
</div>

{{component.calendar}}