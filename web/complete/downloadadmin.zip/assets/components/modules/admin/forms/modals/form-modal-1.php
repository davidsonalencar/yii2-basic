<!-- Form Modal 1 -->
<a href="#modal-1" data-toggle="modal"  class="btn btn-primary"> Modal Example 1</a>
	
<!-- Modal -->
<div class="modal fade" id="modal-1">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal heading -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title">Login</h3>
			</div>
			<!-- // Modal heading END -->
			
			<!-- Modal body -->
			<div class="modal-body">
				{{php.input-horizontal}}
			</div>
			<!-- // Modal body END -->
	
		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}