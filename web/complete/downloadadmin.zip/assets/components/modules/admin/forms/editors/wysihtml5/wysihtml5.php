<!-- Widget -->
<div class="widget widget-heading-simple widget-body-gray">
	
	<!-- Widget heading -->
	<div class="widget-head">
		<h4 class="heading">WYSIHTML5 Editor</h4>
	</div>
	<!-- // Widget heading END -->
	
	<div class="widget-body">
		<textarea id="mustHaveId" class="wysihtml5 form-control" rows="5">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.</textarea>
	</div>
</div>
<!-- // Widget END -->
{{component.wysihtml5}}