<div class="row">
  <div class="col-xs-3">
    <input type="text" class="form-control" placeholder="col 3">
  </div>
  <div class="col-xs-4">
    <input type="text" class="form-control" placeholder="col 4">
  </div>
  <div class="col-xs-5">
    <input type="text" class="form-control" placeholder="col 5">
  </div>
</div>
{{component.input}}