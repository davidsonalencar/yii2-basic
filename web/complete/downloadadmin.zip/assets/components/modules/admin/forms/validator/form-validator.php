<!-- Form -->
<form class="form-horizontal margin-none" id="validateSubmitForm" method="get" autocomplete="off">
	
	<!-- Widget -->
	<div class="widget widget-inverse">
	
		<!-- Widget heading -->
		<div class="widget-head">
			<h4 class="heading">Validate a form with jQuery</h4>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
		
			<!-- Row -->
			<div class="row">
			
				<!-- Column -->
				<div class="col-md-4">
				
					<!-- Group -->
					<div class="form-group">
						<label class="col-md-4 control-label" for="firstname">