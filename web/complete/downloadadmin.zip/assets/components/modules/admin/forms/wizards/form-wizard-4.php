{{component.form-wizards}}
<!-- Form Wizard / Widget Pills -->
<div class="wizard">
	<div class="widget widget-tabs widget-wizard-pills widget-tabs-gray">
	
		<!-- Widget heading -->
		<div class="widget-head">
			<ul>
				<li class="status"><span class="r">Step <span class="step-current">2</span> of <span class="steps-total">5</span></span><span class="r text-primary">Completed: <span class="steps-complete">1</span></span></li>
				<li class="active no-padding"><a href="#tab1-3" data-toggle="tab">1</a></li>
				<li><a href="#tab2-3" data-toggle="tab">2</a></li>
				<li><a href="#tab3-3" data-toggle="tab">3</a></li>
				<li><a href="#tab4-3" data-toggle="tab">4</a></li>
			</ul>
		</div>
		<!-- // Widget heading END -->
		
		<div class="widget-body">
			<div class="tab-content">
			
				<!-- Step 1 -->
				<div class="tab-pane active" id="tab1-3">
					<div class="row">
						<div class="col-md-3">
							<strong>