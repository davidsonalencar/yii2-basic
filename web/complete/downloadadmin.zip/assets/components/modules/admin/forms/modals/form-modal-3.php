<!-- Form Modal 3 -->
<a href="#modal-3" data-toggle="modal"  class="btn btn-inverse"> Modal Example 3</a>
	
<!-- Modal -->
<div class="modal fade" id="modal-3">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal body -->
			<div class="modal-body padding-none">
				{{php.form-wizard-4}}
			</div>
			<!-- // Modal body END -->
	
		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}