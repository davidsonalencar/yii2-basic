{{component.form-wizards}}
{{less.progress-bars}}
<!-- Form Wizard / Arrow navigation & Progress bar -->
<div id="rootwizard" class="wizard">

	<!-- Wizard heading -->
	<div class="wizard-head">
		<ul>
			<li><a href="#tab1" data-toggle="tab">First</a></li>
			<li><a href="#tab2" data-toggle="tab">Second</a></li>
			<li><a href="#tab3" data-toggle="tab">Third</a></li>
			<li><a href="#tab4" data-toggle="tab">Fourth</a></li>
			<li><a href="#tab5" data-toggle="tab">Fifth</a></li>
			<li><a href="#tab6" data-toggle="tab">Sixth</a></li>
			<li><a href="#tab7" data-toggle="tab">Seventh</a></li>
		</ul>
	</div>
	<!-- // Wizard heading END -->
	
	<div class="widget">
	
		<!-- Wizard Progress bar -->
		<div class="widget-head progress" id="bar">
			<div class="progress-bar progress-bar-primary">Step <strong class="step-current">1</strong> of <strong class="steps-total">3</strong> - <strong class="steps-percent">100%</strong></div>
		</div>
		<!-- // Wizard Progress bar END -->
		
		<div class="widget-body">
			<div class="tab-content">
			
				<!-- Step 1 -->
				<div class="tab-pane active" id="tab1">
					<div class="row">
						<div class="col-md-3">
							<strong>