<input class="form-control" id="focusedInput" type="text" value="This is focused...">
{{component.input}}