<input type="text" placeholder="Disabled Input" class="form-control " disabled />
{{component.input}}