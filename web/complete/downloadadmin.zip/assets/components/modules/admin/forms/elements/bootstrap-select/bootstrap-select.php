<!-- Widget -->
<div class="widget widget-inverse">

	<!-- Widget heading -->
	<div class="widget-head">
		<h4 class="heading">Select controls</h4>
	</div>
	<!-- // Widget heading END -->
	
	<div class="widget-body">
		<div class="row">
			<div class="col-md-3">
				<h5>Default</h5>
				<div class="row">
					<div class="innerLR innerB">
						<select class="col-md-12 form-control">
							<optgroup label="Picnic">
								<option>Mustard</option>
								<option>Ketchup</option>
								<option>Relish</option>
							</optgroup>
							<optgroup label="Camping">
								<option>Tent</option>
								<option>Flashlight</option>
								<option>Toilet Paper</option>
							</optgroup>
						</select>
					</div>
				</div>
				<h5>Extended</h5>
				<div class="row">
					<select class="selectpicker col-md-12">
						<optgroup label="Picnic">
							<option>Mustard</option>
							<option>Ketchup</option>
							<option>Relish</option>
						</optgroup>
						<optgroup label="Camping">
							<option>Tent</option>
							<option>Flashlight</option>
							<option>Toilet Paper</option>
						</optgroup>
					</select>
				</div>
			</div>
			<div class="col-md-5">
				<h5>Styles</h5>
				<div class="row">
					<select class="selectpicker col-md-6" data-style="btn-primary">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select> 
					<select class="selectpicker col-md-6" data-style="btn-default">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
				<div class="row">
					<select class="selectpicker col-md-6" data-style="btn-info">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
					<select class="selectpicker col-md-6" data-style="btn-success">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
				<div class="row">
					<select class="selectpicker col-md-6" data-style="btn-warning">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select> 
					<select class="selectpicker col-md-6" data-style="btn-inverse">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
			</div>
			<div class="col-md-4">
				<h5>Grid</h5>
				<div class="row">
					<select class="selectpicker col-md-3">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select> 
					<select class="selectpicker col-md-9">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
				<div class="row">
					<select class="selectpicker col-md-4">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select> 
					<select class="selectpicker col-md-8">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
				<div class="row">
					<select class="selectpicker col-md-6">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select> 
					<select class="selectpicker col-md-6">
						<option>Mustard</option>
						<option>Ketchup</option>
						<option>Relish</option>
					</select>
				</div>
			</div>
		</div>
	
	</div>
</div>
<!-- // Widget END -->
{{component.bootstrap-select}}