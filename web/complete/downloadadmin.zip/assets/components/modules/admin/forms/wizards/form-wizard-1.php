{{component.form-wizards}}

<!-- Form Wizard / Widget Tabs / Vertical -->
	<div class="wizard">
		<div class="widget widget-tabs widget-tabs-double widget-tabs-vertical row row-merge widget-tabs-gray">
		
			<!-- Widget heading -->
			<div class="widget-head col-md-3">
				<ul>
					<li class="active"><a href="#tab1-4" class="glyphicons user" data-toggle="tab"><i></i><span class="strong">Step 1</span><span>Personal details</span></a></li>
					<li><a href="#tab2-4" class="glyphicons calculator" data-toggle="tab"><i></i><span class="strong">Step 2</span><span>Billing details</span></a></li>
					<li><a href="#tab3-4" class="glyphicons credit_card" data-toggle="tab"><i></i><span class="strong">Step 3</span><span>Payment</span></a></li>
					<li><a href="#tab4-4" class="glyphicons circle_ok" data-toggle="tab"><i></i><span class="strong">Step 4</span><span>Confirmation</span></a></li>
				</ul>
			</div>
			<!-- // Widget heading END -->
			
			<div class="widget-body col-md-9">
				<div class="tab-content">
				
					<!-- Step 1 -->
					<div class="tab-pane active" id="tab1-4">
						<div class="row">
							<div class="col-md-3">
								<strong>