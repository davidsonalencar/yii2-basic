<input type="text" placeholder="Large Input" class="form-control input-lg" />
{{component.input}}