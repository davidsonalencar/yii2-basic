<!-- Form Modal 2 -->
<a href="#modal-2" data-toggle="modal"  class="btn btn-info"> Modal Example 2</a>
	
<!-- Modal -->
<div class="modal fade" id="modal-2">
	
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal body -->
			<div class="modal-body padding-none">
				{{php.form-wizard-3}}
			</div>
			<!-- // Modal body END -->
			<div class="modal-footer center">
					<a href="#" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</a> 
			</div>
		</div>
	</div>
	
</div>
<!-- // Modal END -->

{{component.modals}}
{{less.modal-inline}}
{{less.buttons}}