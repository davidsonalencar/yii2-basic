<input type="text" class="form-control" placeholder="Help Block below Input">
<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
{{component.input}}