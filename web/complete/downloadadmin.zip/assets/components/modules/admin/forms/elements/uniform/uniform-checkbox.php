<!-- Widget -->
<div class="widget widget-inverse" data-toggle="collapse-widget">

	<!-- Widget heading -->
	<div class="widget-head">
		<h4 class="heading">Checkbox</h4>
	</div>
	<!-- // Widget heading END -->
	
	<div class="widget-body uniformjs">
		<label class="checkbox">
			<input type="checkbox" class="checkbox" value="1" />
			Option 1 - Sexy checkbox
		</label>
		<label class="checkbox">
			<input type="checkbox" class="checkbox" value="1" checked="checked" />
			Option 2 - Checked
		</label>
		<label class="checkbox">
			<input type="checkbox" class="checkbox" value="1" disabled="disabled" />
			Option 3 - Disabled checkbox
		</label>
	</div>
</div>
<!-- // Widget END -->

{{component.uniformjs}}