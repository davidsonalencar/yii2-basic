<!-- Widget -->
<div class="widget widget-inverse" data-toggle="collapse-widget">

	<!-- Widget heading -->
	<div class="widget-head">
		<h4 class="heading">Radio</h4>
	</div>
	<!-- // Widget heading END -->
	
	<div class="widget-body uniformjs">
		<label class="radio">
			<input type="radio" class="radio" name="radio" value="1" /> Option 1 - Sexy radio
		</label><br/>
		<label class="radio">
			<input type="radio" class="radio" name="radio" value="1" checked="checked" /> Option 2 - Checked
		</label><br/>
		<label class="radio">
			<input type="radio" class="radio disabled" name="radio" value="1" disabled="disabled" /> Option 3 - Disabled radio
		</label>
	</div>
</div>
<!-- // Widget END -->

{{component.uniformjs}}