<!-- Row -->
<div class="row">

	<!-- Column -->
	<div class="col-md-6">
	
		<!-- Widget -->
		<div class="widget widget-inverse">
		
			<!-- Widget heading -->
			<div class="widget-head">
				<h4 class="heading">Loading button</h4>
			</div>
			<!-- // Widget heading END -->
			
			<div class="widget-body center">{{php.button-loading}}</div>
			
		</div>
		<!-- // Widget END -->
		
		<!-- Widget -->
		<div class="widget widget-inverse">
		
			<!-- Widget heading -->
			<div class="widget-head">
				<h4 class="heading">Toggle button</h4>
			</div>
			<!-- // Widget heading END -->
			
			<div class="widget-body center">{{php.button-toggle-single}}</div>

		</div>
		<!-- // Widget END -->
	
	</div>
	<!-- // Column END -->
	
	<!-- Column -->
	<div class="col-md-6">
	
		<!-- Widget -->
		<div class="widget widget-inverse">
		
			<!-- Widget heading -->
			<div class="widget-head">
				<h4 class="heading">Toggle checkbox style</h4>
			</div>
			<!-- // Widget heading END -->
			
			<div class="widget-body center">{{php.button-toggle-checkbox}}</div>

		</div>
		<!-- // Widget END -->
		
		<!-- Widget -->
		<div class="widget widget-inverse">
		
			<!-- Widget heading -->
			<div class="widget-head">
				<h4 class="heading">Toggle radio style</h4>
			</div>
			<!-- // Widget heading END -->
			
			<div class="widget-body center">{{php.button-toggle-radio}}</div>

		</div>
		<!-- // Widget END -->
	
	</div>
	<!-- // Column END -->
	
</div>
<!-- // Row END -->
{{ignore.docs}}