<h2 class="margin-none separator bottom"><i class="icon-group text-primary icon-fixed-width"></i> Employee Directory</h2>
			<div class="widget widget-heading-simple widget-body-gray widget-employees">
				<div class="widget-body padding-none">
					
					<div class="row">
						<div class="col-md-4 listWrapper">
							<div class="innerAll">
								<form autocomplete="off" class="form-inline">
									<div class="widget-search separator bottom">
										<button type="button" class="btn btn-default pull-right"><i class="icon-search"></i></button>
										<div class="overflow-hidden">
											<input type="text" value="" class="form-control" placeholder="Find someone ..">
										</div>
									</div>
									<select style="width: 100%;">
						               <optgroup label="Department">
						                   <option value="design">Design</option>
						                   <option value="development">Development</option>
						               </optgroup>
									</select>
								</form>
							</div>
							<span class="results">1490 Employees Found <i class="icon-circle-arrow-down"></i></span>
							<ul class="list unstyled">
																<li>
									<div class="media innerAll">
										<div class="media-object pull-left thumb hidden-phone"><img src="