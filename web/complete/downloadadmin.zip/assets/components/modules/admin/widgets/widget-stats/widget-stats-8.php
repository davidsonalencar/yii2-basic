<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-info widget-stats-5">
	<span class="glyphicons envelope"><i></i></span>
	<span class="txt">New<span>Emails</span></span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}