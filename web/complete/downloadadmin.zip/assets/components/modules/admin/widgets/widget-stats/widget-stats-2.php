<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-1">
	<span class="glyphicons shield"><i></i><span class="txt">Alerts</span></span>
	<div class="clearfix"></div>
	<span class="count">125</span>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}