<!-- Widget With Progress Bar -->

<div class="widget">
	<div class="widget-head progress" id="widget-progress-bar">
		<div class="progress-bar progress-bar-primary">Lorem ipsum <strong>dolor</strong> - <strong class="steps-percent">100%</strong></div>
	</div>
	<div class="widget-body">
		<h4>Progress Widget</h4>
		<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
	</div>
</div>
<!-- // Widget With Progress Bar END -->

{{component.widget-progress}}
{{less.progress-bars}}