<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-primary widget-stats-5">
	<span class="glyphicons wifi_alt"><i></i></span>
	<span class="txt">User<span>Activity</span></span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}