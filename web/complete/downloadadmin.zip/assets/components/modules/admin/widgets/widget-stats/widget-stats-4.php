<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-2">
	<span class="count">30</span>
	<span class="txt">Bookings</span>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}