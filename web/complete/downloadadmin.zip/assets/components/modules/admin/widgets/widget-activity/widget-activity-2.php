<!-- Activity/List Widget -->
<h2 class="margin-none separator bottom"><i class="icon-signal text-primary icon-fixed-width"></i> Activity</h2>
<div class="widget widget-heading-simple widget-body-gray" data-toggle="collapse-widget">
	<div class="widget-body list">
		<ul>
		
			<!-- List item -->
			<li>
				<span>Sales today</span>
				<span class="count">&euro;5,900</span>
			</li>
			<!-- // List item END -->
			
			<!-- List item -->
			<li>
				<span>Some other stats</span>
				<span class="count">36,900</span>
			</li>
			<!-- // List item END -->
			
			<!-- List item -->
			<li>
				<span>Some stunning stats</span>
				<span class="count">26,999</span>
			</li>
			<!-- // List item END -->
			
			<!-- List item -->
			<li>
				<span>Awesome stats</span>
				<span class="count">4,900</span>
			</li>
			<!-- // List item END -->
			
		</ul>
	</div>
</div>
<!-- // Activity/List Widget END -->

{{component.widget-activity}}