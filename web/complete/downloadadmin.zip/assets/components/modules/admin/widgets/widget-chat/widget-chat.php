<!-- Chat -->
<div class="widget widget-inverse widget-chat" data-builder-exclude>

	<div class="widget-head">
		<h4 class="heading"><i class="icon-comment-fill-1"></i> Chat</h3>
	</div>
	<div class="widget-body padding-none border-bottom">
	
	<!-- Slim Scroll -->
	<div class="slim-scroll chat-items" data-scroll-height="235px" data-scroll-size="0">
		
		<!-- Media item -->
		<div class="media innerAll border-bottom">
			<small class="author"><a href="#" title="" class="strong">Martin</a></small>
			<img src="../assets/images/people/50/2.jpg" alt="" class="img-circle media-object pull-left">
			<div class="media-body">
				<small class="date"><cite>just now</cite></small>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vitae accumsan mauris. Donec vitae nibh felis, facilisis bibendum sapien.</p>
			</div>
		</div>
		<!-- // Media item END -->
		
		<!-- Media item -->
		<div class="media innerAll border-bottom right">
			<small class="author"><a href="#" title="" class="strong">John Doe</a></small>
		    <img src="../assets/images/people/50/5.jpg" alt="" class="img-circle media-object pull-right" > 
			<div class="media-body">
				<small class="date"><cite>15 seconds ago</cite></small>
				<p>In ultricies ante eget tortor euismod vitae molestie eros hendrerit. Cras tristique, orci ac lacinia aliquet, velit risus laoreet lectus, eget sollicitudin metus orci non nulla.</p>
			</div>
		</div>
		<!-- // Media item END -->
		
		<!-- Media item -->
		<div class="media innerAll">
			<small class="author"><a href="#" title="" class="strong">Ricky</a></small>
		    <img src="../assets/images/people/50/7.jpg" alt="" class="img-circle media-object pull-left" > 
			<div class="media-body">
				<small class="date"><cite>5 minutes ago</cite></small>
				<p>Pellentesque ac turpis turpis. Aliquam erat volutpat. Proin semper auctor mauris vel tempor. Ut eget turpis neque. Nam ultricies tortor eu odio ultricies euismod.</p>
			</div>
		</div>
		<!-- // Media item END -->
		
	</div>
	<!-- // Slim Scroll END -->
	
	</div>
	
	<div class="chat-controls bg-default innerAll half">
		<div class="">
			<form class="margin-none">
				<div class="input-group">
					<input type="text" name="message" class="form-control" placeholder="Type your message .." />
					<div class="input-group-btn">
						<a type="submit" class="btn btn-primary"><i class="fa fa-comments-o"></i></a>
					</div>
				</div>
			</form>
		</div>
	</div>
	
</div>
<!-- // Chat END -->

{{component.widget-chat}}
{{builder.saveComponent.original}}