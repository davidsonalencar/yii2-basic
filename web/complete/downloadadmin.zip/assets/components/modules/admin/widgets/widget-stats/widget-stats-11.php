<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-gray widget-stats-4">
	<span class="txt">Signups</span>
	<span class="count">3<span>Today</span></span>
	<span class="glyphicons user"><i></i></span>
	<div class="clearfix"></div>
	<i class="icon-play-circle"></i>
</a>
<!-- // Stats Widget END -->

{{component.widget-stats}}