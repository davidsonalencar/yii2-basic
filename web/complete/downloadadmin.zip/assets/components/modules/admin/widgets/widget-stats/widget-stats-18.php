<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-2 widget-stats-gray widget-stats-easy-pie txt-single">
	<div data-percent="35" class="easy-pie primary easyPieChart"><span class="value">35</span>%</div>
	<span class="txt">Server workload</span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}
{{component.easy-pie-charts}}