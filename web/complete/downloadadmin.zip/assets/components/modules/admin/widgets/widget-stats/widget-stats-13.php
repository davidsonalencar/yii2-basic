<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-default widget-stats-4">
	<span class="txt">Ratings</span>
	<span class="count">4.3</span>
	<span class="glyphicons cup"><i></i></span>
	<div class="clearfix"></div>
	<i class="icon-play-circle"></i>
</a>
<!-- // Stats Widget END -->

{{component.widget-stats}}