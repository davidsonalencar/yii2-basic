<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-gray widget-stats-1">
	<span class="glyphicons cart_in"><i></i><span class="txt">Sales</span></span>
	<div class="clearfix"></div>
	<span class="count">20</span>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}