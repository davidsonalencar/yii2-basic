<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-gray widget-stats-2 widget-stats-easy-pie txt-single">
	<div data-percent="85" class="easy-pie danger"><span class="value">85</span>%</div>
	<span class="txt">Workload</span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->

{{component.widget-stats}}
{{component.easy-pie-charts}}