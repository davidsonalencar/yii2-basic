<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-2 widget-stats-easy-pie widget-stats-primary">
	<div data-percent="23" class="easy-pie primary easyPieChart"><span class="value">23</span>%</div>
	<span class="txt"><span class="count text-large inline-block">130</span> ROI</span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}
{{component.easy-pie-charts}}