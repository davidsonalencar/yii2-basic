<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-gray widget-stats-2">
	<span class="count">2</span>
	<span class="txt">Orders</span>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}