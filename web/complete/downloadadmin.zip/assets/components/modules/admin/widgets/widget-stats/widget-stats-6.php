<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-2 widget-stats-easy-pie txt-single">
	<div data-percent="90" class="easy-pie success"><span class="value">90</span>%</div>
	<span class="txt">Completed</span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->

{{component.widget-stats}}
{{component.easy-pie-charts}}