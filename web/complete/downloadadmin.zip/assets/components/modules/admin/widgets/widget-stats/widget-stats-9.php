<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-inverse widget-stats-5">
	<span class="glyphicons parents"><i></i></span>
	<span class="txt">Recent<span>Signups</span></span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}