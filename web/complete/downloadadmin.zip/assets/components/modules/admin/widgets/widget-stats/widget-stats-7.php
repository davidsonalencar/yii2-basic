<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-default widget-stats-5">
	<span class="glyphicons cart_in"><i></i></span>
	<span class="txt">Latest<span>Orders</span></span>
	<div class="clearfix"></div>
</a>
<!-- // Stats Widget END -->
{{component.widget-stats}}