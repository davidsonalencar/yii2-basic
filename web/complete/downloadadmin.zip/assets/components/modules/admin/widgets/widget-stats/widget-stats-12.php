<!-- Stats Widget -->
<a href="" class="widget-stats widget-stats-primary widget-stats-4">
	<span class="txt">Progress</span>
	<span class="count">58%</span>
	<span class="glyphicons refresh"><i></i></span>
	<div class="clearfix"></div>
	<i class="icon-play-circle"></i>
</a>
<!-- // Stats Widget END -->

{{component.widget-stats}}