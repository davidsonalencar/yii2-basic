<!-- Tabs -->
<div class="widget widget-tabs widget-tabs-social-account widget-tabs-responsive">

	<!-- Tabs Heading -->
	<div class="widget-head">
		<ul>
			<li class="active"><a class="glyphicons user" href="#tabAccount" data-toggle="tab"><i></i><span>Account</span></a></li>
			<li><a class="glyphicons credit_card" href="#tabPayments" data-toggle="tab"><i></i><span>Payment</span></a></li>
			<li><a class="glyphicons envelope" href="#tabInbox" data-toggle="tab"><i></i><span>Inbox</span></a></li>
			<li><a class="glyphicons lock" href="#tabPassword" data-toggle="tab"><i></i><span>Password</span></a></li>
		</ul>
	</div>
	<!-- // Tabs Heading END -->
	<div class="col-separator-h box"></div>
	<div class="widget-body">
		<div class="tab-content">
		
			<!-- Tab content -->
			<div id="tabAccount" class="tab-pane active widget-body-regular padding-none border-none reset-components">
				{{php.profile-my-account}}
			</div>
			<!-- // Tab content END -->
			
			<!-- Tab content -->
			<div id="tabPayments" class="tab-pane innerAll">
				<h4 class="innerTB">Payment &amp; Billing Information</h4>
				<div class="row">
					<div class="col-md-9">
						<div class="box-generic bg-primary">
							<a href="#" class="btn btn-default btn-xs pull-right"><i class="fa fa-times "></i></a>
							 <h4 class="text-white strong"><i class="fa fa-credit-card innerR"></i> XXXX XXXX XXXX XXXX1209</h4>
						</div>
						<div class="box-generic">
							<div class="pull-right btn-group btn-group-xs">
								<a href="#" class="btn btn-default"><i class="fa fa-check "></i> Make Primary</a>
								<a href="" class="btn btn-default"><i class="fa fa-times"></i></a>
							</div>
							 <h4 class="strong"><i class="fa fa-credit-card innerR"></i> XXXX XXXX XXXX XXXX1209</h4>
						</div>
						<div class="box-generic padding-none">
							<h5 class="strong innerAll border-bottom margin-none bg-gray">Add New Card</h5>
							<div class="innerAll">
								<form>
								  	<div class="form-group">
								    	<label for="exampleInputEmail1">Card Number</label>
								    	<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter Card Number">
								  	</div>
								  	<div class="form-group">
										<div class="row">
											<div class="col-xs-6">
									    		<label for="exampleInputPassword1">Expiry Date</label>
												<div class="row">
										  			<div class="col-xs-6">
										     			<select class="form-control">
											  				<option>1</option>
											  				<option>2</option>
											  				<option>3</option>
											  				<option>4</option>
											  				<option>5</option>
											  				<option>6</option>
											  				<option>7</option>
											  				<option>8</option>
											  				<option>9</option>
										  					<option>10</option>
											  				<option>11</option>
														</select>
										  			</div>
										  			<div class="col-xs-6">
										      			<select class="form-control">
															<option>2013</option>
														  	<option>2014</option>
														  	<option>2015</option>
														  	<option>2016</option>
														  	<option>2017</option>
														  	<option>2018</option>
														</select>
										  			</div>
										  		</div>
									  		</div>
									  		<div class="col-xs-6">
									    		<label for="exampleInputPassword1">Security Code <i class="fa fa-question-circle"></i></label>
									  			<input type="password" class="form-control" placeholder="CVV / CVV2">
									  		</div>
										</div>
								  	</div>
								 	<div class="form-group">
								    	<label for="exampleInputEmail1">Cardholder Name</label>
								    	<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Name on Card">
								  	</div>
									<div class="text-right">
								  		<button type="submit" class="btn btn-primary">Submit Card Details <i class="fa fa-plus"></i></button>
								  	</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-3">
					  	<div class="box-generic strong">
						  	<i class="fa fa-user fa-3x pull-left text-faded"></i> Adrian Demian <br/><small class="text-faded">12 Nov 2013</small>
						</div>    
					    <div class="box-generic padding-none">
					        <div class="innerAll border-bottom">
					        	<a href="" class="pull-right text-primary"><i class="fa fa-pencil"></i></a>
					          	<h4 class="panel-title strong">Billing Address </h4>
					        </div>
					        <div class="innerAll">
					        	<i class="fa fa-building pull-left fa-3x"></i> <span>129 Longford Terrace, Dublin, Ireland</span>
					        </div>
					    </div>

					</div>
				</div>
			</div>
			<!-- // Tab content END -->
			
			<!-- Tab content -->
			<div id="tabInbox" class="tab-pane">
				{{php.email}}
			</div>
			<!-- // Tab content END -->
			
			<!-- Tab content -->
			<div id="tabPassword" class="tab-pane innerAll">
				<h4 class="innerTB">Change your Password</h4>
				<form class="form-horizontal innerT " role="form">
				  <div class="form-group">
				    <label for="inputEmail3" class="col-sm-2 control-label">Current Password</label>
				    <div class="col-sm-6">
				      <input type="email" class="form-control" id="inputEmail3" placeholder="Type here">
				    </div>
				  </div>
				  <div class="form-group">
				    <label for="inputPassword3" class="col-sm-2 control-label">New Password</label>
				    <div class="col-sm-6">
				      <input type="password" class="form-control" id="inputPassword3" placeholder="Type here">
				    </div>
				  </div>
				 
				  <div class="form-group">
				    <div class="col-sm-offset-2 col-sm-10">
				      <button type="submit" class="btn btn-primary">Save Changes <i class="fa fa-check"></i></button>
				    </div>
				  </div>
				</form>
				
			</div>
			<!-- // Tab content END -->
			
		</div>
	</div>
</div>
<!-- // Tabs END -->

{{component.tabs}}
{{component.widget-generic}}